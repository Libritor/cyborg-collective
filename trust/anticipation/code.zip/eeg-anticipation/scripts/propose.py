"""The local language model proposes claims about the aggregate tables; the gate disposes.

    python scripts/propose.py [--model ornith:9b] [--n 12] [--dry-run] [--blind] [--name blind]

Ornith only sees: the column dictionary, counts per pool and condition, group means of a few statistics, and (unless
--blind) the forecasting summary. Never a raw sample. Writes results/proposals[_name]/{prompt.txt,raw_reply.txt,
ledger.jsonl,session_table.json} and results/PROPOSALS[_NAME].md. Without Ollama the script records that the proposer
was unavailable and writes no claims.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.request

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))

from anticipate import claims  # noqa: E402
from anticipate.epochs import Session  # noqa: E402

FEAT = os.path.join(ROOT, "results", "features")
FORE = os.path.join(ROOT, "results", "forecast")
OLLAMA = "http://localhost:11434/api/chat"


def session_table() -> list[dict]:
    idx = json.load(open(os.path.join(FEAT, "index.json"), encoding="utf-8"))
    skills = {}
    rec_path = os.path.join(FORE, "records.json")
    if os.path.exists(rec_path):
        rec = json.load(open(rec_path, encoding="utf-8"))
        for pool in ("mine", "cold", "all"):
            for h, name in ((1, "skill_A_h1"), (4, "skill_A_h4")):
                for r in rec.get(f"{pool}/A", {}).get(f"ridge_all@{h}", []):
                    if r["sse_persist"] > 0:
                        skills.setdefault(r["key"], {})[name] = 1.0 - r["sse_model"] / r["sse_persist"]
                    if h == 1 and r["sse_mean"] > 0:
                        skills.setdefault(r["key"], {})["skill_mean_A_h1"] = 1.0 - r["sse_model"] / r["sse_mean"]
    rows = []
    for key, info in idx.items():
        if "minutes" not in info or "skipped" in info or "failed" in info:
            continue
        s = Session.from_npz(os.path.join(FEAT, key + ".npz"))
        u = s.usable
        with np.errstate(invalid="ignore"):
            lb = np.where(s.accepted[:, :, None], s.logband, np.nan)
            bands = np.nanmean(np.nanmean(lb, axis=1)[u], axis=0) if u.any() else [np.nan] * 4
        row = {"key": key, "pools": info["pools"], "condition": info.get("condition") or "", "tag": info.get("tag"),
               "minutes": info["minutes"], "usable_fraction": info["usable_fraction"],
               "mean_index": float(np.nanmean(s.index)) if u.any() else float("nan"),
               "sd_index": float(np.nanstd(s.index)) if u.any() else float("nan"),
               "mean_logtheta": float(bands[0]), "mean_logalpha": float(bands[1]), "mean_logbeta": float(bands[2]),
               "mean_loggamma": float(bands[3]),
               "gyro_rms_mean": float(np.nanmean(s.gyro_rms)) if np.isfinite(s.gyro_rms).any() else float("nan")}
        row.update(skills.get(key, {}))
        rows.append(row)
    return rows


def briefing(table: list[dict], summary: dict | None, blind: bool = False) -> str:
    def count(pred):
        return sum(1 for r in table if pred(r))
    lines = ["COLUMN DICTIONARY (one row per recording session of a 4-electrode consumer EEG headband, 2 s epochs):",
             "  minutes; usable_fraction (share of epochs passing the contact + 200 uV gate); mean_index and sd_index "
             "(the activation index log10((beta+gamma)/(theta+alpha)) over usable epochs); mean_logtheta/alpha/beta/gamma "
             "(log10 band power, channel mean); gyro_rms_mean (head motion); skill_A_h1, skill_A_h4 (forecast skill of "
             "a ridge model over persistence 2 s and 8 s ahead, within-session, held-out time); skill_mean_A_h1 (the same "
             "against the session mean). Missing skills = the session had too few valid sequences.",
             "POOLS: mine = the owner's own head; cold = the lab's cold-exposure periods (wearer mixed); all = every "
             "session; mine_sleep = one overnight recording. A session can be in mine and cold at once (filter by "
             "condition, or compare mine against cold/unlabelled, to keep two groups disjoint).",
             "CONDITIONS (from the filename only): pre (before a plunge), post (after), warm, cold, sleep, unlabelled.",
             "COUNTS:"]
    for p in claims.POOLS:
        lines.append(f"  pool {p}: {count(lambda r: p in r['pools'])} sessions")
    for c in ("pre", "post", "warm", "cold", "sleep"):
        lines.append(f"  condition {c}: {count(lambda r: r['condition'] == c)} sessions (in cold: "
                     f"{count(lambda r: r['condition'] == c and 'cold' in r['pools'])})")
    lines.append("GROUP MEANS (pool: usable_fraction, mean_index, mean_logalpha, gyro_rms_mean, skill_A_h1):")
    for p in claims.POOLS:
        R = [r for r in table if p in r["pools"]]
        if not R:
            continue
        f = lambda k: np.nanmean([r.get(k, np.nan) for r in R])  # noqa: E731
        lines.append(f"  {p}: {f('usable_fraction'):.2f}, {f('mean_index'):.3f}, {f('mean_logalpha'):.2f}, "
                     f"{f('gyro_rms_mean'):.1f}, {f('skill_A_h1'):.3f}" if not blind else
                     f"  {p}: {f('usable_fraction'):.2f}, {f('mean_index'):.3f}, {f('mean_logalpha'):.2f}, "
                     f"{f('gyro_rms_mean'):.1f}, (forecast skill withheld in this round)")
    if summary and not blind:
        lines.append("FORECAST SUMMARY (pooled skill over persistence [95% interval], ridge_all, protocol A):")
        for pool in ("mine", "cold", "all"):
            cells = summary["cells"].get(f"{pool}/A", {})
            parts = []
            for h in (1, 2, 4, 8):
                c = cells.get(f"ridge_all@{h}")
                if c:
                    parts.append(f"h={h}: {c['persist']['pooled']:+.3f} [{c['persist']['pooled_ci'][0]:+.3f}, {c['persist']['pooled_ci'][1]:+.3f}]")
            if parts:
                lines.append(f"  {pool}: " + "; ".join(parts))
    elif blind:
        lines.append("FORECAST SUMMARY: withheld in this round. Forecast claims are predictions: state the skill you expect "
                     "a ridge model on 16 s of history to reach over persistence, at the horizon you choose.")
    lines.append(f"RULES OF THE GATE: a group comparison needs at least {claims.MIN_GROUP} sessions per group and the groups "
                 f"must not overlap; a correlation needs at least {claims.MIN_CORR} sessions; Holm correction across all "
                 "your claims; a forecast claim is supported only if the held-out pooled skill is at least min_skill with "
                 "an interval excluding zero.")
    return "\n".join(lines)


SYSTEM = ("You are a careful neuroscientist proposing falsifiable claims about a small EEG dataset. You see only the "
          "briefing. Reply with JSON only: {\"claims\": [...]}, each claim exactly in one of these three forms:\n"
          "{\"id\": \"c1\", \"type\": \"compare_groups\", \"stat\": STAT, \"group_a\": {\"pool\": POOL, \"condition\": COND}, "
          "\"group_b\": {\"pool\": POOL, \"condition\": COND}, \"direction\": \">\" or \"<\", \"rationale\": \"...\"}\n"
          "{\"id\": \"c2\", \"type\": \"correlation\", \"x\": STAT, \"y\": STAT, \"pool\": POOL, \"sign\": \"+\" or \"-\", \"rationale\": \"...\"}\n"
          "{\"id\": \"c3\", \"type\": \"forecast\", \"pool\": POOL, \"protocol\": \"A\" or \"B\", \"model\": \"ridge_lags\" or \"ridge_all\" or \"gru\", "
          "\"horizon\": 1, 2, 4 or 8, \"min_skill\": number, \"rationale\": \"...\"}\n"
          f"STAT is one of {claims.STATS}. POOL is one of {claims.POOLS}. COND is one of {claims.CONDITIONS}. "
          "Propose what you believe is true of such data, including claims about cold exposure, about the owner's own "
          "head, and about how far ahead the signal can be forecast. Do not propose the same claim twice.")


def ask_ollama(model: str, prompt: str, n: int, timeout: int = 600) -> str:
    body = {"model": model, "stream": False, "format": "json", "think": False,
            "options": {"temperature": 0.7, "num_predict": 3000},
            "messages": [{"role": "system", "content": SYSTEM},
                         {"role": "user", "content": prompt + f"\n\nPropose {n} claims now."}]}
    req = urllib.request.Request(OLLAMA, data=json.dumps(body).encode("utf-8"), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        d = json.loads(r.read())
    return d.get("message", {}).get("content", "")


def parse_claims(text: str) -> list[dict]:
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
    try:
        d = json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, re.S)
        if not m:
            return []
        try:
            d = json.loads(m.group(0))
        except json.JSONDecodeError:
            return []
    if isinstance(d, list):
        return [c for c in d if isinstance(c, dict)]
    return [c for c in (d.get("claims") or []) if isinstance(c, dict)]


def describe(c: dict) -> str:
    t = c.get("type")
    if t == "compare_groups":
        g = lambda x: f"{x.get('pool', 'all')}/{x.get('condition', 'any')}"  # noqa: E731
        return f"{c.get('stat')} in {g(c.get('group_a', {}))} {c.get('direction')} {g(c.get('group_b', {}))}"
    if t == "correlation":
        return f"{c.get('x')} {c.get('sign')} {c.get('y')} across {c.get('pool', 'all')}"
    if t == "forecast":
        return f"{c.get('model')} on {c.get('pool')}/{c.get('protocol', 'A')} h={c.get('horizon')}: skill >= {c.get('min_skill')}"
    return json.dumps(c)[:80]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="ornith:9b")
    ap.add_argument("--n", type=int, default=12)
    ap.add_argument("--dry-run", action="store_true", help="write the briefing only; do not call the model")
    ap.add_argument("--blind", action="store_true", help="withhold the forecast numbers from the briefing (the gate still reads them)")
    ap.add_argument("--name", default="", help="suffix for the output folder and the report, e.g. blind")
    a = ap.parse_args()
    out = os.path.join(ROOT, "results", "proposals" + (f"_{a.name}" if a.name else ""))
    report = os.path.join(ROOT, "results", "PROPOSALS" + (f"_{a.name.upper()}" if a.name else "") + ".md")
    os.makedirs(out, exist_ok=True)
    table = session_table()
    sp = os.path.join(FORE, "summary.json")
    summary = json.load(open(sp, encoding="utf-8")) if os.path.exists(sp) else None
    prompt = briefing(table, summary, blind=a.blind)
    open(os.path.join(out, "prompt.txt"), "w", encoding="utf-8").write(SYSTEM + "\n\n" + prompt)
    json.dump(table, open(os.path.join(out, "session_table.json"), "w", encoding="utf-8"), indent=1, default=float)
    if a.dry_run:
        print(prompt)
        return 0
    t0 = time.time()
    try:
        raw = ask_ollama(a.model, prompt, a.n)
    except Exception as e:  # noqa: BLE001 - no model, no claims; never invent them
        msg = f"proposer unavailable: {type(e).__name__}: {e}"
        open(report, "w", encoding="utf-8").write(f"# Proposals\n\n{msg}\n")
        print(msg)
        return 2
    open(os.path.join(out, "raw_reply.txt"), "w", encoding="utf-8").write(raw)
    proposed = parse_claims(raw)[: a.n]
    results = [claims.test_claim(c, table, summary) for c in proposed]
    results = claims.decide(results)
    with open(os.path.join(out, "ledger.jsonl"), "w", encoding="utf-8") as f:
        for c, r in zip(proposed, results):
            f.write(json.dumps({"claim": c, "result": r, "tier": claims.TIER[r["outcome"]]}, default=float) + "\n")
    counts = {k: sum(1 for r in results if r["outcome"] == k) for k in ("supported", "refuted", "not_supported", "abstain", "malformed")}
    seen = os.path.relpath(os.path.join(out, "prompt.txt"), ROOT).replace(os.sep, "/")
    L = ["# A local model proposes, the gate disposes" + (" (blind round: the forecast numbers withheld)" if a.blind else ""), "",
         f"Model: {a.model} through Ollama, on this laptop, {time.time() - t0:.0f} s, temperature 0.7, JSON mode. "
         f"It saw the briefing in `{seen}` (column dictionary, counts, group means"
         + (", no forecast numbers" if a.blind else ", the forecast summary") + f") and nothing else. {len(proposed)} claims parsed from its reply.", "",
         "| # | claim | outcome | tier | numbers |", "|---|---|---|---|---|"]
    for i, (c, r) in enumerate(zip(proposed, results), 1):
        nums = {k: v for k, v in r.items() if k not in ("outcome",)}
        L.append(f"| {i} | {describe(c)} | {r['outcome']} | {claims.TIER[r['outcome']]} | {json.dumps(nums, default=lambda x: round(float(x), 4))[:220]} |")
    L += ["", "## Count", "", "| proposed | supported | refuted | not supported | abstain | malformed |", "|---|---|---|---|---|---|",
          f"| {len(proposed)} | {counts['supported']} | {counts['refuted']} | {counts['not_supported']} | {counts['abstain']} | {counts['malformed']} |", "",
          "Supported means the stated direction survives a permutation test with Holm correction across every claim the model "
          "made (or, for a forecast claim, the held-out interval clears the stated skill). Nothing here is verified in the "
          "exact sense; the best tier is empirical. The rationale the model gave for each claim is in the ledger.", ""]
    open(report, "w", encoding="utf-8").write("\n".join(L))
    print(json.dumps(counts), f"{time.time() - t0:.0f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
