"""MuseLog CSV -> gated 2 s epochs for every recording in the pools. Skips files already done.

    python scripts/build_features.py [--min-minutes 3] [--only mine|cold|all]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "src"))

from anticipate import epochs, pools  # noqa: E402

OUT = os.path.join(os.path.dirname(HERE), "results", "features")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-minutes", type=float, default=3.0)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    recs = pools.discover()
    if a.only:
        recs = [r for r in recs if a.only in r.pools]
    index_path = os.path.join(OUT, "index.json")
    done = json.load(open(index_path, encoding="utf-8")) if os.path.exists(index_path) else {}
    t0 = time.time()
    kept = skipped = failed = 0
    for i, r in enumerate(recs):
        npz = os.path.join(OUT, r.key + ".npz")
        if r.key in done and os.path.exists(npz):
            continue
        size_mb = os.path.getsize(r.path) / 1e6
        if size_mb < 0.5:                                  # under half a megabyte cannot hold 3 minutes
            done[r.key] = {"skipped": "too small", "mb": round(size_mb, 2), "pools": r.pools}
            skipped += 1
            continue
        try:
            s = epochs.extract(r.path, stamp=r.stamp, device=r.tag,
                               meta={"pools": list(r.pools), "condition": r.condition, "folder": r.folder})
        except Exception as e:  # noqa: BLE001 - one bad file must not stop the batch
            done[r.key] = {"failed": f"{type(e).__name__}: {e}"[:200], "pools": r.pools}
            failed += 1
            traceback.print_exc(limit=1)
            continue
        if s.duration_s < a.min_minutes * 60:
            done[r.key] = {"skipped": "short", "minutes": round(s.duration_s / 60, 2), "pools": r.pools}
            skipped += 1
            continue
        s.to_npz(npz)
        done[r.key] = {"minutes": round(s.duration_s / 60, 2), "usable_fraction": round(s.usable_fraction, 3),
                       "pools": list(r.pools), "condition": r.condition, "tag": r.tag, "mb": round(size_mb, 1),
                       "hsi_known": bool(s.meta.get("hsi_known")), "gyro": bool(s.meta.get("have_gyro"))}
        kept += 1
        if kept % 10 == 0:
            json.dump(done, open(index_path, "w", encoding="utf-8"), indent=1)
            print(f"{i + 1}/{len(recs)} kept {kept} skipped {skipped} failed {failed}  {time.time() - t0:.0f}s", flush=True)
    json.dump(done, open(index_path, "w", encoding="utf-8"), indent=1)
    print(f"done: {len(recs)} recordings seen, {kept} new, {skipped} skipped, {failed} failed, {time.time() - t0:.0f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
