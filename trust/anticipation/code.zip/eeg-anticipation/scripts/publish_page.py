"""Render the public page of this study for 6ense.com in the home page's own look: full width, the masthead with the
figure in a dark panel, tiles, cards, the honesty footer. Plain HTML, no script. Also writes the page's stylesheet
(the home page's style.css is loaded first), every number as a file, the pre-registration with other wearers'
initials removed, the two proposer ledgers, and the code as a zip. Nothing published names a wearer or carries a
raw sample; the script refuses to write if it would.

    python scripts/publish_page.py <output folder>      e.g. C:\\Users\\alexa\\cyborg-collective-site\\trust\\anticipation
"""
from __future__ import annotations

import html
import json
import os
import re
import shutil
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))
from propose import describe  # noqa: E402

RES = os.path.join(ROOT, "results")
HOR = [1, 2, 4, 8]
REDACT = [("(one author, whose Drive copies are tagged SM: not the owner)", "(one author, not the owner)"),
          ("whose Drive copies are tagged SM: not the owner", "not the owner")]

CSS = """/* The anticipation page, in the home page's own look: ../../style.css is loaded first, this after it. */
.crumb { margin: 0 0 2px; font-size: 13px; color: var(--muted); }
.crumb a { color: inherit; }
nav a[aria-current="page"] { color: var(--ink); border-color: var(--ink); }
:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; border-radius: 4px; }
.masthead > .side { grid-column: 1; min-width: 0; }
@media (max-width: 900px) {
  .masthead { grid-template-columns: minmax(0, 1fr); grid-template-rows: none; }
  .masthead > .band-col { display: contents; }
  .masthead > header.top { order: 1; }
  .masthead .dark-panel { order: 2; margin-top: 14px; }
  .masthead > nav { order: 3; }
  .masthead > .side { order: 4; }
  .masthead > header.top, .masthead > nav, .masthead > .side, .masthead .dark-panel { grid-column: 1; grid-row: auto; }
  .grid { grid-template-columns: minmax(0, 1fr); }
}
/* a dark panel, dark in both themes as the home page's are */
.dark-panel { margin: 0; min-width: 0; background: #0b0e14; border: 1px solid #1c212b; border-radius: 12px; color: #aeb7c4; overflow: hidden; }
.dark-panel figcaption { padding: 9px 14px 0; font-size: 12px; line-height: 1.4; color: #aeb7c4; }
.dark-panel figcaption b { color: #e5e7eb; }
.dark-panel .how { margin: 4px 14px 10px; font-size: 12px; color: #7d8794; }
.dark-panel .how a { color: #e0b366; }
.dark-panel a.fig { display: block; line-height: 0; }
.dark-panel img { display: block; width: 100%; height: auto; padding: 6px 8px 0; }
/* the findings, numbered cards */
.steps { list-style: none; padding: 0; margin: 10px 0 0; display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 14px; counter-reset: step; }
.steps li { counter-increment: step; font-size: 14px; }
.steps li b { display: block; margin-bottom: 4px; font-size: 15px; }
.steps li b::before { content: counter(step) ". "; color: var(--muted); }
.cards .card { font-size: 14px; }
.cards .card b { display: block; margin-bottom: 4px; }
.tier { display: inline-block; font-size: 11px; padding: 2px 7px; border-radius: 999px; background: var(--soft); color: var(--muted); white-space: nowrap; }
.tier-verified { color: var(--good); } .tier-refused { color: var(--bad); } .tier-estimated { color: var(--ok); }
table.numbers { margin: 8px 0 4px; }
table.numbers td.n { font-variant-numeric: tabular-nums; }
main p { max-width: 90ch; }
.files { padding-left: 18px; } .files li { margin: 4px 0; }
"""


def esc(s) -> str:
    return html.escape(str(s), quote=True)


def redacted(text: str) -> str:
    for a, b in REDACT:
        text = text.replace(a, b)
    return text


def cell(summary, key, model, h, against="persist"):
    c = summary["cells"].get(key, {}).get(f"{model}@{h}")
    return c[against] if c else None


def fmt(c, ci=True):
    if not c:
        return "·"
    s = f"{c['pooled']:+.2f}"
    if ci:
        s += f" [{c['pooled_ci'][0]:+.2f}, {c['pooled_ci'][1]:+.2f}]"
    return s


def recording_level():
    p = os.path.join(RES, "features", "index.json")
    if not os.path.exists(p):
        return {}
    idx = json.load(open(p, encoding="utf-8"))
    kept = [v for v in idx.values() if "minutes" in v and "skipped" not in v and "failed" not in v]
    out = {}
    for pool in ("mine", "cold", "all"):
        R = [v for v in kept if pool in v["pools"]]
        out[pool] = {"n": len(R), "usable": sum(v["usable_fraction"] for v in R) / len(R) if R else float("nan")}
    return out


def ledger(name):
    p = os.path.join(RES, name, "ledger.jsonl")
    rows = []
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            rows.append(json.loads(line))
    return rows


def numbers_of(r: dict) -> str:
    keep = ("difference", "cliffs_delta", "rho", "n", "n_a", "n_b", "p_stated_holm", "pooled_skill", "ci", "min_skill", "reason")
    parts = []
    for k in keep:
        if k in r:
            v = r[k]
            if isinstance(v, float):
                v = f"{v:.3f}"
            elif isinstance(v, list):
                v = "[" + ", ".join(f"{x:+.3f}" for x in v) + "]"
            parts.append(f"{k} {v}")
    return "; ".join(parts)


def counts_of(rows):
    return {k: sum(1 for r in rows if r["result"]["outcome"] == k) for k in ("supported", "refuted", "not_supported", "abstain", "malformed")}


def ledger_table(rows, title):
    if not rows:
        return f"<h3>{esc(title)}</h3><p class='sub'>No ledger.</p>"
    c = counts_of(rows)
    out = [f"<h3>{esc(title)}</h3>",
           f"<p class='sub'>{len(rows)} claims: {c['supported']} supported, {c['refuted']} refuted, "
           f"{c['not_supported']} inconclusive at this n, {c['abstain']} abstained, {c['malformed']} malformed.</p>",
           "<div class='table-scroll'><table class='numbers'><thead><tr><th>#</th><th>The claim</th><th>Outcome</th><th>What the gate saw</th><th>The model's reason</th></tr></thead><tbody>"]
    for i, r in enumerate(rows, 1):
        oc = r["result"]["outcome"]
        tier = {"supported": "tier-verified", "refuted": "tier-refused", "not_supported": "tier-estimated", "abstain": "", "malformed": "tier-refused"}[oc]
        label = {"supported": "supported (empirical)", "refuted": "refuted", "not_supported": "inconclusive", "abstain": "abstain", "malformed": "malformed"}[oc]
        out.append(f"<tr><td>{i}</td><td>{esc(describe(r['claim']))}</td><td><span class='tier {tier}'>{label}</span></td>"
                   f"<td class='n'>{esc(numbers_of(r['result']))}</td><td>{esc(r['claim'].get('rationale', ''))}</td></tr>")
    out.append("</tbody></table></div>")
    return "\n".join(out)


def span(values):
    v = [x for x in values if x is not None]
    return (min(v), max(v)) if v else (float("nan"), float("nan"))


def render(summary, rec) -> str:
    pools = summary["pools"]
    P = summary["predictions"]
    g = lambda key, model, h, against="persist": cell(summary, key, model, h, against)  # noqa: E731

    def pool_row(name, label):
        c = pools.get(name, {})
        r = rec.get(name, {})
        left = (f"<td class='n'>{r['n']}</td><td class='n'>{r['usable']:.2f}</td>" if r else "<td class='n'>·</td><td class='n'>·</td>")
        return f"<tr><td>{label}</td>{left}<td class='n'>{c.get('sessions', '·')}</td><td class='n'>{c.get('minutes', 0):.0f}</td></tr>"

    def skill_rows(proto, against):
        rows = []
        for pool, label in (("mine", "the owner's head"), ("cold", "cold periods"), ("all", "all")):
            cells = [g(f"{pool}/{proto}", "ridge_lags", h, against) for h in HOR]
            rows.append(f"<tr><td>{label}</td>" + "".join(f"<td class='n'>{fmt(c)}</td>" for c in cells) + "</tr>")
        return "\n".join(rows)

    # headline numbers, read from the run
    lags_pers = span([g(f"{p}/{pr}", "ridge_lags", h)["pooled"] for p in ("mine", "cold", "all") for pr in ("A", "B") for h in HOR
                      if g(f"{p}/{pr}", "ridge_lags", h)])
    mean_pers = span([g(f"{p}/A", "session_mean", h)["pooled"] for p in ("mine", "cold") for h in HOR if g(f"{p}/A", "session_mean", h)])
    beyond = span([g(f"{p}/{pr}", "ridge_lags", 1, "mean")["pooled"] for p in ("mine", "cold") for pr in ("A", "B") if g(f"{p}/{pr}", "ridge_lags", 1, "mean")])
    am, bm = g("all->mine", "ridge_all", 1), g("mine/B", "ridge_all", 1)
    r1, r2 = ledger("proposals"), ledger("proposals_blind")
    c1, c2 = counts_of(r1), counts_of(r2)
    tot = {k: c1[k] + c2[k] for k in c1}
    n_claims = len(r1) + len(r2)
    rec_cold, rec_mine, rec_all = rec.get("cold", {}), rec.get("mine", {}), rec.get("all", {})
    elig_all, elig_mine, elig_cold = pools["all"]["sessions"], pools["mine"]["sessions"], pools["cold"]["sessions"]
    scorecard = {
        "P1": "On the owner's head, within a session, skill over persistence at 2 s between 0.05 and 0.30",
        "P2": "Skill over the session mean falls with horizon and is at most 0.05 at 16 s, in every pool",
        "P3": "The GRU never beats ridge by more than 0.05",
        "P4": "Across-session ridge exceeds within-session ridge at 2 s by at most 0.03",
        "P5": "A model trained on other heads reads the owner's within 0.05 of one trained on his own",
        "P6": "The cold pool's skill at 2 s is within 0.10 of the owner's",
        "P7": "The cold pool's usable fraction is lower than the owner's by at least 0.15 (as worded, inside the eligible pools)",
    }
    verdict = lambda k: "supported" if P[k]["supported"] else "refuted"  # noqa: E731
    about = ("On the owner's own head and on the lab's cold-exposure recordings, the question was how much of the next 2 to 16 s "
             "is already in the last 16 s, and whether a local language model, shown only the aggregate tables, says anything about "
             "the data that the same gate lets stand. Everything ran on one laptop; the raw recordings never left it; the design was "
             "written down and committed before the first run.")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>How far ahead can a headband be read?</title>
<meta name="description" content="A pre-registered test of anticipating a Muse headband's activation index 2 to 16 s ahead, under the gates the lab's papers use, with a local language model's claims judged by the same gate.">
<meta property="og:type" content="website">
<meta property="og:title" content="How far ahead can a headband be read?">
<meta property="og:description" content="Ridge on the last 16 s removes {lags_pers[0]:.2f} to {lags_pers[1]:.2f} of persistence's error 2 to 16 s ahead; most of it is drift back to the level; nothing personal at these horizons; no plunge is in it.">
<!-- Written by publish_page.py of the eeg-anticipation repository. No script on this page. -->
<link rel="stylesheet" href="../../style.css">
<link rel="stylesheet" href="anticipation.css">
</head>
<body>
<div class="masthead">
<header class="top">
  <p class="crumb"><a href="../../">Cyborg Collective</a> · <a href="../../#trust">Trust</a></p>
  <h1>How far ahead can a headband be read?</h1>
  <p class="tag">A pre-registered test of anticipating a Muse headband's activation index 2 to 16 s ahead, under the gates the lab's papers use.</p>
  <p class="about">{about}</p>
</header>
<nav aria-label="Anticipation">
  <a href="../../">Home</a><a href="../../#trust">Trust</a><a href="#data">The data</a><a href="#found">What was found</a><a href="#model">The model's claims</a><a href="#limits">What it does not show</a><a href="#files">Files</a><a href="../../record.html">The record</a>
</nav>
<div class="side">
<p class="status">Pre-registered in <a href="PREDICTIONS.md">PREDICTIONS.md</a>, with two amendments made before the first run. Rerun it yourself: <a href="code.zip">code.zip</a>, pointed at a folder of MuseLog recordings, rebuilds every number on this page in a few minutes on a laptop.</p>
</div>
<div class="band-col">
<figure class="dark-panel">
<figcaption><b>6ense™</b> anticipation · pooled skill against how far ahead, 2 to 16 s, three pools of recordings</figcaption>
<a class="fig" href="skill_by_horizon.pdf"><img src="skill_by_horizon_dark.svg" width="1440" height="1080" alt="Four panels of pooled forecast skill against horizon (2, 4, 8, 16 s) for three pools, within a session and across sessions, against persistence and against the session mean, with bootstrap intervals"></a>
<p class="how">Skill = 1 − MSE(model)/MSE(baseline), ridge on the last 16 s of the index, 95 % intervals from 2000 session bootstraps. Left: against "it stays where it is". Right: against the session's own mean. Top: trained on the first 60 % of a session, tested on the last 40 %. Bottom: trained on other sessions. Two cold points at 4 s are off the scale: one session's within-session model, the variant with band and motion features, extrapolated badly; the lags-only model did not. <a href="skill_by_horizon.svg">Light version</a> · <a href="skill_by_horizon.pdf">PDF</a></p>
</figure>
</div>
</div>
<main>
<section id="data">
  <h2>What the data allowed</h2>
  <p class="sub">A recording entered a pool only if it was at least 3 minutes long and yielded 60 clean, contiguous 18-second windows under the gate: contact 2 or better on the electrode, under 200 µV peak to peak, 90 % of the samples arrived, two of four electrodes accepted. The gate, not the analyst, decided who got in.</p>
  <div class="tiles">
    <div class="tile"><b>{elig_all} of {rec_all.get('n', '·')}</b><span>recordings of 3 minutes or more passed the gate</span></div>
    <div class="tile"><b>{pools['mine']['minutes']:.0f} min</b><span>of the owner's head in play, {elig_mine} sessions, one afternoon</span></div>
    <div class="tile"><b>{pools['cold']['minutes']:.0f} min</b><span>from the cold-exposure periods, {elig_cold} sessions, no plunge</span></div>
    <div class="tile"><b>{rec_cold.get('usable', float('nan')):.2f} vs {rec_mine.get('usable', float('nan')):.2f}</b><span>usable fraction of the cold-period recordings against the owner's</span></div>
    <div class="tile"><b>0</b><span>recordings labelled before or after a plunge that passed</span></div>
  </div>
  <div class="table-scroll"><table class="numbers"><thead><tr><th>Pool</th><th>Recordings ≥ 3 min</th><th>Usable fraction, mean</th><th>Eligible</th><th>Minutes used</th></tr></thead><tbody>
{pool_row("mine", "the owner's head")}
{pool_row("cold", "cold periods")}
{pool_row("all", "all")}
</tbody></table></div>
  <div class="grid cards">
    <div class="card"><b>One afternoon</b>The six eligible sessions of the owner's head are all from 2025-12-13, recorded while the recorder was being written. "My head" here means one day of it.</div>
    <div class="card"><b>No plunge</b>No recording labelled as before or after a plunge reached 60 clean windows. The cold pool is six recordings from the cold-exposure periods, wearers unnamed and not the owner. Nothing here is a plunge response.</div>
    <div class="card"><b>Coverage, not skill, separates cold from calm</b>7 % of the cold-period recordings qualify against 43 % of the owner's. The pre-registered P7 compared usable fractions inside the eligible pools and is refuted as worded; at the recording level the gap is 0.11 against 0.45.</div>
  </div>
</section>

<section id="found">
  <h2>What was found</h2>
  <p class="sub">Seven things. Every number is in the tables below and in <a href="FORECAST.md">FORECAST.md</a>.</p>
  <div class="tiles">
    <div class="tile"><b>{lags_pers[0]:.2f} to {lags_pers[1]:.2f}</b><span>of persistence's error removed by ridge on 16 s of history, 2 to 16 s ahead, every pool, held out</span></div>
    <div class="tile"><b>{mean_pers[0]:.2f} to {mean_pers[1]:.2f}</b><span>removed by the session's own mean alone, owner and cold pools</span></div>
    <div class="tile"><b>{beyond[0]:+.2f} to {beyond[1]:+.2f}</b><span>beyond the mean at 2 s, owner and cold pools; nothing left by 16 s</span></div>
    <div class="tile"><b>{am['pooled']:.3f} vs {bm['pooled']:.3f}</b><span>other heads' model on the owner's sessions, against his own</span></div>
  </div>
  <ol class="steps">
    <li class="card"><b>The index can be anticipated 2 to 16 s ahead, relative to "it stays where it is".</b> Ridge on the last eight values removes {lags_pers[0]:.2f} to {lags_pers[1]:.2f} of persistence's squared error in every pool, on held-out time and on held-out sessions, every interval clear of zero.</li>
    <li class="card"><b>Most of that is drift back to the session's level.</b> The session mean by itself, used as the forecast, removes {mean_pers[0]:.2f} to {mean_pers[1]:.2f} of persistence's error in the owner's and the cold pools. The game's quantity wanders about a level and persistence chases the noise.</li>
    <li class="card"><b>Beyond the level, 16 s of history adds a little at 2 s and nothing by 16 s.</b> A within-session permutation test, which shuffles the older history while every target keeps its own current value, says the past does carry information (p = 0.005 in all six primary cells, Holm-adjusted 0.030); the amount is a few hundredths to 0.16 of the error.</li>
    <li class="card"><b>Nothing personal at these horizons.</b> A model trained on other people's sessions anticipates the owner's as well as one trained on his own ({am['pooled']:.3f} against {bm['pooled']:.3f}).</li>
    <li class="card"><b>The small recurrent network lost to ridge everywhere.</b> Fifty to two hundred minutes per pool is not enough for it.</li>
    <li class="card"><b>The pre-registered primary model was the fragile one.</b> Ridge with band powers and motion added extrapolated badly on two January sessions when trained on a session's first 60 %; lags alone did not. Three predictions read as refuted for that reason; the lags-only numbers are the ones to trust, and both are published.</li>
    <li class="card"><b>Asleep the picture inverts.</b> In the one overnight recording persistence is a good baseline and the mean a bad one. One night; an observation.</li>
  </ol>
  <h3>Skill, ridge on the lags, trained on other sessions</h3>
  <p class="sub">Pooled skill with its 95 % interval; columns are how far ahead.</p>
  <div class="table-scroll"><table class="numbers"><thead><tr><th>against persistence</th><th>2 s</th><th>4 s</th><th>8 s</th><th>16 s</th></tr></thead><tbody>
{skill_rows("B", "persist")}
</tbody></table></div>
  <div class="table-scroll"><table class="numbers"><thead><tr><th>against the session mean</th><th>2 s</th><th>4 s</th><th>8 s</th><th>16 s</th></tr></thead><tbody>
{skill_rows("B", "mean")}
</tbody></table></div>
  <h3>The pre-registered predictions</h3>
  <div class="table-scroll"><table class="numbers"><thead><tr><th></th><th>Prediction</th><th>Verdict</th></tr></thead><tbody>
{"".join(f"<tr><td>{k}</td><td>{esc(v)}</td><td><span class='tier {'tier-verified' if P[k]['supported'] else 'tier-refused'}'>{verdict(k)}</span></td></tr>" for k, v in scorecard.items())}
</tbody></table></div>
  <p>P1 is refuted upward: the owner's head was more predictable than written, for the reason in point 2. P2, P4 and P6 fall to the fragile model in point 6 and to this n. The design, with the two amendments made before the first run, is in <a href="PREDICTIONS.md">PREDICTIONS.md</a>.</p>
</section>

<section id="model">
  <h2>A local model proposes, the gate disposes</h2>
  <p class="sub">Ornith, a 9-billion-parameter model running on the laptop through Ollama, saw only a briefing: the column dictionary, counts per pool and condition, group means, and in the first round the forecasting summary. It was asked for twelve falsifiable claims in a fixed grammar (two groups compared on a statistic, a correlation across sessions, or a forecast-skill statement). Each claim met a permutation test or the held-out forecast result, with Holm correction across all its claims, groups under five sessions abstaining.</p>
  <div class="tiles">
    <div class="tile"><b>{n_claims}</b><span>claims in two rounds</span></div>
    <div class="tile"><b>{tot['supported']}</b><span>let through as empirical</span></div>
    <div class="tile"><b>{tot['refuted']}</b><span>refuted, both textbook intuitions</span></div>
    <div class="tile"><b>{tot['not_supported']}</b><span>inconclusive at this n</span></div>
    <div class="tile"><b>{tot['malformed']}</b><span>malformed: groups that overlap</span></div>
  </div>
{ledger_table(r1, "Round one: the model saw the forecast numbers")}
{ledger_table(r2, "Round two, blind: the forecast numbers withheld")}
  <div class="card" style="margin-top:14px"><b>Reading the two rounds together</b><p>Shown the forecast numbers, the model proposed them back; shown none, it proposed no forecast at all. Its supported claims are correlations that are nearly definitional on a four-electrode headband. Its refuted claims are textbook intuitions (beta and gamma fall as alpha rises) that run the other way across these sessions, where every band moves with amplitude and contact. It compared "the owner" with "cold periods" seven times in a way the gate could not test, after being told how. And once it set a negative skill threshold and called the result "marginally supported"; the gate returned inconclusive. The gate held every time. The ledger is the result, not the count of green rows.</p></div>
</section>

<section id="limits">
  <h2>What this does not show</h2>
  <div class="card"><p>It does not show that a plunge response can be anticipated, that any mental state is read, or that the index after a plunge means arousal rather than muscle. Anticipation at 2 to 4 s is real and is mostly reversion to the level, which is exactly what a game can use to cancel its one to two seconds of latency. Anticipating the response to cold needs marked plunges (in and out markers, a 60 s baseline, 10 to 15 minutes after exit) and a leave-one-plunge-out test, which is the next thing to record.</p></div>
</section>

<section id="files">
  <h2>Files</h2>
  <ul class="files">
    <li><a href="PREDICTIONS.md">The pre-registration</a>, committed before the first run, with its two amendments.</li>
    <li><a href="FORECAST.md">Every forecasting cell</a>: both protocols, three models and two baselines, four horizons, intervals, the permutation null, the Holm-adjusted primary cells.</li>
    <li><a href="PROPOSALS.md">Round one</a> and <a href="PROPOSALS_BLIND.md">round two</a> of the proposer, with <a href="proposals_round1_prompt.txt">what it was shown</a> (<a href="proposals_round2_prompt.txt">blind</a>), <a href="proposals_round1_reply.txt">what it replied</a> (<a href="proposals_round2_reply.txt">blind</a>) and the ledgers (<a href="proposals_round1_ledger.jsonl">1</a>, <a href="proposals_round2_ledger.jsonl">2</a>).</li>
    <li><a href="skill_by_horizon.svg">The figure</a> (light), <a href="skill_by_horizon_dark.svg">dark</a>, <a href="skill_by_horizon.pdf">PDF</a>.</li>
    <li><a href="code.zip">The code</a>: the epoch gate, the pools, the forecasting, the claim grammar, the tests and the scripts.</li>
  </ul>
</section>
</main>
<footer>
  <b>How this page is honest</b>
  <ul>
    <li>The gate is the one in the lab's Buzzkill paper, applied before any model saw a sample: contact, 200 µV, 90 % of samples, two electrodes. Recordings that failed it are counted, not dropped quietly.</li>
    <li>The design was committed before the first run; its two amendments were made before the first run and are recorded with their reasons. Predictions that failed are reported as failed.</li>
    <li>Skill is measured on held-out time or held-out sessions, against two baselines, with intervals from resampling sessions. Nothing here is verified in the exact sense; the best a forecast or a proposed claim earns is empirical, with its interval.</li>
    <li>The language model saw aggregate tables and nothing else; its claims, its reasons and the gate's verdicts are published in full. The per-session tables it saw are not, because their keys carry the recordings' names.</li>
    <li>The raw recordings stay with the people who made them. No plunge is in this study, and the page says so wherever it matters.</li>
  </ul>
</footer>
</body>
</html>
"""


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    summary = json.load(open(os.path.join(RES, "forecast", "summary.json"), encoding="utf-8"))
    rec = recording_level()
    open(os.path.join(out, "index.html"), "w", encoding="utf-8", newline="\n").write(render(summary, rec))
    open(os.path.join(out, "anticipation.css"), "w", encoding="utf-8", newline="\n").write(CSS)
    for name in ("skill_by_horizon.svg", "skill_by_horizon_dark.svg", "skill_by_horizon.pdf"):
        shutil.copy(os.path.join(RES, "forecast", name), os.path.join(out, name))
    for name in ("FORECAST.md", "PROPOSALS.md", "PROPOSALS_BLIND.md"):
        shutil.copy(os.path.join(RES, name), os.path.join(out, name))
    open(os.path.join(out, "PREDICTIONS.md"), "w", encoding="utf-8", newline="\n").write(
        redacted(open(os.path.join(ROOT, "PREDICTIONS.md"), encoding="utf-8").read()))
    for round_, folder in (("round1", "proposals"), ("round2", "proposals_blind")):
        for src, dst in (("prompt.txt", f"proposals_{round_}_prompt.txt"), ("raw_reply.txt", f"proposals_{round_}_reply.txt"),
                         ("ledger.jsonl", f"proposals_{round_}_ledger.jsonl")):
            p = os.path.join(RES, folder, src)
            if os.path.exists(p):
                shutil.copy(p, os.path.join(out, dst))
    # the code, from the working tree, without results and with the redacted pre-registration
    with zipfile.ZipFile(os.path.join(out, "code.zip"), "w", zipfile.ZIP_DEFLATED) as z:
        for rel in ("README.md", ".gitignore"):
            z.write(os.path.join(ROOT, rel), f"eeg-anticipation/{rel}")
        z.writestr("eeg-anticipation/PREDICTIONS.md", redacted(open(os.path.join(ROOT, "PREDICTIONS.md"), encoding="utf-8").read()))
        for folder in ("src", "scripts", "tests"):
            for dp, dn, fn in os.walk(os.path.join(ROOT, folder)):
                dn[:] = [d for d in dn if d != "__pycache__"]
                for f in fn:
                    if f.endswith(".py"):
                        full = os.path.join(dp, f)
                        z.write(full, "eeg-anticipation/" + os.path.relpath(full, ROOT).replace(os.sep, "/"))
    # nothing published may carry another wearer's name or the raw tags
    bad = re.compile(r"ChanBefore|Chris|SARAH|GIA|LUCIA|MARIO|P\d{3}\b|tagged SM")
    for f in sorted(os.listdir(out)):
        if f.endswith((".html", ".md", ".txt", ".jsonl", ".css")):
            text = open(os.path.join(out, f), encoding="utf-8", errors="replace").read()
            m = bad.search(text)
            if m:
                sys.exit(f"REFUSING to publish: {f} contains {m.group(0)!r}")
    print("wrote", out, ":", ", ".join(sorted(os.listdir(out))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
