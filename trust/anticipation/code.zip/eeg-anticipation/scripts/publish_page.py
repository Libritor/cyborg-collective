"""Render the public page of this study for 6ense.com: plain HTML (no script), the figure, the honest reading, the
pre-registration (initials of other wearers removed), every number as a file, the two proposer ledgers with the
model's own rationales, and the code as a zip. Nothing published names a wearer or carries a raw sample.

    python scripts/publish_page.py <output folder>      e.g. C:\\Users\\alexa\\cyborg-collective-site\\trust\\anticipation
"""
from __future__ import annotations

import html
import json
import os
import re
import shutil
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))
from propose import describe  # noqa: E402

RES = os.path.join(ROOT, "results")
HOR = [1, 2, 4, 8]
REDACT = [("(one author, whose Drive copies are tagged SM: not the owner)", "(one author, not the owner)"),
          ("whose Drive copies are tagged SM: not the owner", "not the owner")]


def esc(s) -> str:
    return html.escape(str(s), quote=True)


def redacted(text: str) -> str:
    for a, b in REDACT:
        text = text.replace(a, b)
    return text


def cell(summary, key, model, h, against="persist"):
    c = summary["cells"].get(key, {}).get(f"{model}@{h}")
    return c[against] if c else None


def fmt(c, ci=True):
    if not c:
        return "·"
    s = f"{c['pooled']:+.2f}"
    if ci:
        s += f" [{c['pooled_ci'][0]:+.2f}, {c['pooled_ci'][1]:+.2f}]"
    return s


def recording_level():
    p = os.path.join(RES, "features", "index.json")
    if not os.path.exists(p):
        return {}
    idx = json.load(open(p, encoding="utf-8"))
    kept = [v for v in idx.values() if "minutes" in v and "skipped" not in v and "failed" not in v]
    out = {}
    for pool in ("mine", "cold", "all"):
        R = [v for v in kept if pool in v["pools"]]
        out[pool] = {"n": len(R), "usable": sum(v["usable_fraction"] for v in R) / len(R) if R else float("nan")}
    return out


def ledger(name):
    p = os.path.join(RES, name, "ledger.jsonl")
    rows = []
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            rows.append(json.loads(line))
    return rows


def numbers_of(r: dict) -> str:
    keep = ("difference", "cliffs_delta", "rho", "n", "n_a", "n_b", "p_stated_holm", "pooled_skill", "ci", "min_skill", "reason")
    parts = []
    for k in keep:
        if k in r:
            v = r[k]
            if isinstance(v, float):
                v = f"{v:.3f}"
            elif isinstance(v, list):
                v = "[" + ", ".join(f"{x:+.3f}" for x in v) + "]"
            parts.append(f"{k} {v}")
    return "; ".join(parts)


def ledger_table(rows, title):
    if not rows:
        return f"<p>{esc(title)}: no ledger.</p>"
    counts = {k: sum(1 for r in rows if r["result"]["outcome"] == k) for k in ("supported", "refuted", "not_supported", "abstain", "malformed")}
    out = [f"<h3>{esc(title)}</h3>",
           f"<p class='sub'>{len(rows)} claims: {counts['supported']} supported, {counts['refuted']} refuted, "
           f"{counts['not_supported']} inconclusive at this n, {counts['abstain']} abstained, {counts['malformed']} malformed.</p>",
           "<div class='table-scroll'><table class='numbers'><thead><tr><th>#</th><th>The claim</th><th>Outcome</th><th>What the gate saw</th><th>The model's reason</th></tr></thead><tbody>"]
    for i, r in enumerate(rows, 1):
        oc = r["result"]["outcome"]
        tier = {"supported": "tier-verified", "refuted": "tier-refused", "not_supported": "tier-estimated", "abstain": "", "malformed": "tier-refused"}[oc]
        label = {"supported": "supported (empirical)", "refuted": "refuted", "not_supported": "inconclusive", "abstain": "abstain", "malformed": "malformed"}[oc]
        out.append(f"<tr><td>{i}</td><td>{esc(describe(r['claim']))}</td><td><span class='tier {tier}'>{label}</span></td>"
                   f"<td class='n'>{esc(numbers_of(r['result']))}</td><td>{esc(r['claim'].get('rationale', ''))}</td></tr>")
    out.append("</tbody></table></div>")
    return "\n".join(out)


def render(summary, rec) -> str:
    pools = summary["pools"]
    P = summary["predictions"]
    g = lambda key, model, h, against="persist": cell(summary, key, model, h, against)  # noqa: E731

    def pool_row(name, label):
        c = pools.get(name, {})
        r = rec.get(name, {})
        return (f"<tr><td>{label}</td><td class='n'>{r.get('n', '·')}</td><td class='n'>{r['usable']:.2f}</td>" if r else
                f"<tr><td>{label}</td><td class='n'>·</td><td class='n'>·</td>") + \
            f"<td class='n'>{c.get('sessions', '·')}</td><td class='n'>{c.get('minutes', 0):.0f}</td></tr>"

    def skill_rows(proto, against):
        rows = []
        for pool, label in (("mine", "mine"), ("cold", "cold periods"), ("all", "all")):
            cells = [g(f"{pool}/{proto}", "ridge_lags", h, against) for h in HOR]
            rows.append(f"<tr><td>{label}</td>" + "".join(f"<td class='n'>{fmt(c)}</td>" for c in cells) + "</tr>")
        return "\n".join(rows)

    mean_vs_pers = [g(f"{p}/A", "session_mean", 1) for p in ("mine", "cold")]
    verdict = lambda k: "supported" if P[k]["supported"] else "refuted"  # noqa: E731
    scorecard = {
        "P1": "On the owner's head, within a session, skill over persistence at 2 s between 0.05 and 0.30",
        "P2": "Skill over the session mean falls with horizon and is at most 0.05 at 16 s, in every pool",
        "P3": "The GRU never beats ridge by more than 0.05",
        "P4": "Across-session ridge exceeds within-session ridge at 2 s by at most 0.03",
        "P5": "A model trained on other heads reads the owner's within 0.05 of one trained on his own",
        "P6": "The cold pool's skill at 2 s is within 0.10 of the owner's",
        "P7": "The cold pool's usable fraction is lower than the owner's by at least 0.15 (as worded, inside the eligible pools)",
    }
    r1, r2 = ledger("proposals"), ledger("proposals_blind")
    am, bm = g("all->mine", "ridge_all", 1), g("mine/B", "ridge_all", 1)
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>How far ahead can a headband be read?</title>
<link rel="stylesheet" href="../../style.css">
<style>
.page {{ max-width: 980px; margin: 0 auto; padding: 24px 16px 60px; }}
.page h1 {{ font-size: 26px; margin: 0 0 6px; }}
.page h2 {{ font-size: 20px; margin: 30px 0 6px; }}
.page h3 {{ font-size: 16px; margin: 22px 0 4px; }}
.page p, .page li {{ max-width: 78ch; }}
.page figure {{ margin: 18px 0; }}
.page figure img {{ width: 100%; height: auto; background: #fff; border-radius: 10px; }}
.page figcaption {{ color: var(--muted); font-size: 13px; margin-top: 6px; }}
.page .crumbs {{ font-size: 14px; color: var(--muted); margin-bottom: 14px; }}
.page .crumbs a {{ margin-right: 12px; }}
.page table.numbers {{ margin: 8px 0 4px; }}
.page .tier {{ display: inline-block; font-size: 11px; padding: 2px 7px; border-radius: 999px; background: var(--soft); color: var(--muted); white-space: nowrap; }}
.page .files li {{ margin: 3px 0; }}
.page .foot {{ color: var(--muted); font-size: 13px; border-top: 1px solid var(--line); margin-top: 36px; padding-top: 14px; }}
</style>
</head>
<body>
<div class="page">
<p class="crumbs"><a href="../../">6ense.com</a><a href="../../#trust">Trust</a></p>
<h1>How far ahead can a headband be read?</h1>
<p class="sub">A pre-registered test of anticipating the Muse activation index 2 to 16 s ahead, on the owner's own head and on the lab's cold-exposure recordings, with the gates the lab's papers use, and a local language model whose claims about the same data the same gate judged. Everything ran on one laptop; the raw recordings never left it.</p>

<figure>
<a href="skill_by_horizon.pdf"><img src="skill_by_horizon.svg" width="1440" height="1080" alt="Four panels of pooled forecast skill against horizon (2, 4, 8, 16 s) for three pools, within a session and across sessions, against persistence and against the session mean, with bootstrap intervals"></a>
<figcaption>Pooled skill = 1 − MSE(model)/MSE(baseline), ridge on the last 16 s of the index, 95 % intervals from 2000 session bootstraps. Left: against "it stays where it is". Right: against the session's own mean. Top: trained on the first 60 % of a session, tested on the last 40 %. Bottom: trained on other sessions. Two cold points at 4 s are off the scale because one session's within-session model, the variant with band and motion features, extrapolated badly; the lags-only model did not. <a href="skill_by_horizon_dark.svg">Dark version</a> · <a href="skill_by_horizon.pdf">PDF</a>.</figcaption>
</figure>

<h2>What the data allowed</h2>
<p>A recording entered a pool only if it was at least 3 minutes long and yielded 60 clean, contiguous 18-second windows under the gate: contact 2 or better on the electrode, under 200 µV peak to peak, 90 % of the samples arrived, two of four electrodes accepted. The gate, not the analyst, decided who got in.</p>
<div class="table-scroll"><table class="numbers"><thead><tr><th>Pool</th><th>Recordings ≥ 3 min</th><th>Usable fraction, mean</th><th>Eligible</th><th>Minutes used</th></tr></thead><tbody>
{pool_row("mine", "mine (the owner's head)")}
{pool_row("cold", "cold periods")}
{pool_row("all", "all")}
</tbody></table></div>
<ul>
<li>The six eligible sessions of the owner's head are one afternoon, 2025-12-13, recorded while the recorder was being written.</li>
<li>No recording labelled as before or after a plunge reached 60 clean windows. The cold pool is six recordings from the cold-exposure periods, none a plunge, wearers unnamed and not the owner. Nothing here is a plunge response.</li>
<li>Coverage is what separates cold from calm: 7 % of the cold-period recordings qualify against 43 % of the owner's, and the usable fraction at the recording level is 0.11 against 0.45.</li>
</ul>

<h2>What was found</h2>
<ol>
<li><b>The index can be anticipated 2 to 16 s ahead, relative to "it stays where it is".</b> Ridge on the last eight values removes 0.30 to 0.46 of persistence's squared error in every pool, on held-out time and on held-out sessions, every interval clear of zero.</li>
<li><b>Most of that is drift back to the session's level.</b> The session mean by itself, used as the forecast, removes {fmt(mean_vs_pers[0], False)} (owner) and {fmt(mean_vs_pers[1], False)} (cold periods) of persistence's error at 2 s. The game's quantity wanders about a level and persistence chases the noise.</li>
<li><b>Beyond the level, 16 s of history adds a little at 2 s and nothing by 16 s.</b> A within-session permutation test, which shuffles the older history while every target keeps its own current value, says the past does carry information (p = 0.005 in all six primary cells, Holm-adjusted 0.030); the amount is a few hundredths to 0.16 of the error.</li>
<li><b>Nothing personal at these horizons.</b> A model trained on other people's sessions anticipates the owner's as well as one trained on his own ({fmt(am, False) if am else '·'} against {fmt(bm, False) if bm else '·'}).</li>
<li><b>The small recurrent network lost to ridge everywhere.</b> Fifty to two hundred minutes per pool is not enough for it.</li>
<li><b>The pre-registered primary model was the fragile one.</b> Ridge with band powers and motion added extrapolated badly on two January sessions when trained on a session's first 60 %; lags alone did not. Three predictions read as refuted for that reason; the lags-only numbers are the ones to trust, and both are published.</li>
<li><b>Asleep the picture inverts</b>: in the one overnight recording persistence is a good baseline and the mean a bad one. One night; an observation.</li>
</ol>

<h3>Skill, ridge on the lags, trained on other sessions</h3>
<p class="sub">Pooled skill with its interval; columns are how far ahead.</p>
<div class="table-scroll"><table class="numbers"><thead><tr><th>against persistence</th><th>2 s</th><th>4 s</th><th>8 s</th><th>16 s</th></tr></thead><tbody>
{skill_rows("B", "persist")}
</tbody></table></div>
<div class="table-scroll"><table class="numbers"><thead><tr><th>against the session mean</th><th>2 s</th><th>4 s</th><th>8 s</th><th>16 s</th></tr></thead><tbody>
{skill_rows("B", "mean")}
</tbody></table></div>

<h3>The pre-registered predictions</h3>
<div class="table-scroll"><table class="numbers"><thead><tr><th></th><th>Prediction</th><th>Verdict</th></tr></thead><tbody>
{"".join(f"<tr><td>{k}</td><td>{esc(v)}</td><td><span class='tier {'tier-verified' if P[k]['supported'] else 'tier-refused'}'>{verdict(k)}</span></td></tr>" for k, v in scorecard.items())}
</tbody></table></div>
<p>P1 is refuted upward: the owner's head was more predictable than written, for the reason in point 2. P2, P4 and P6 fall to the fragile model in point 6 and to this n. The full design, with the two amendments made before the first run, is in <a href="PREDICTIONS.md">PREDICTIONS.md</a>.</p>

<h2>A local model proposes, the gate disposes</h2>
<p>Ornith, a 9-billion-parameter model running on the laptop through Ollama, saw only a briefing: the column dictionary, counts per pool and condition, group means, and in the first round the forecasting summary. It was asked for twelve falsifiable claims in a fixed grammar (two groups compared on a statistic, a correlation across sessions, or a forecast-skill statement). Each claim met a permutation test or the held-out forecast result, with Holm correction across all its claims, groups under five sessions abstaining. The ledger is the result.</p>
{ledger_table(r1, "Round one: the model saw the forecast numbers")}
{ledger_table(r2, "Round two, blind: the forecast numbers withheld")}
<p>Reading the two rounds together: shown the forecast numbers, the model proposed them back; shown none, it proposed no forecast at all. Its supported claims are correlations that are nearly definitional on a four-electrode headband. Its refuted claims are textbook intuitions (beta and gamma fall as alpha rises) that run the other way across these sessions, where every band moves with amplitude and contact. It compared "the owner" with "cold periods" seven times in a way the gate could not test, after being told how. And once it set a negative skill threshold and called the result "marginally supported"; the gate returned inconclusive. The gate held every time.</p>

<h2>What this does not show</h2>
<p>It does not show that a plunge response can be anticipated, that any mental state is read, or that the index after a plunge means arousal rather than muscle. Anticipation at 2 to 4 s is real and is mostly reversion to the level, which is exactly what a game can use to cancel its one to two seconds of latency. Anticipating the response to cold needs marked plunges (in and out markers, a 60 s baseline, 10 to 15 minutes after exit) and a leave-one-plunge-out test, which is the next thing to record.</p>

<h2>Files</h2>
<ul class="files">
<li><a href="PREDICTIONS.md">The pre-registration</a>, committed before the first run, with its two amendments.</li>
<li><a href="FORECAST.md">Every forecasting cell</a>: both protocols, three models and two baselines, four horizons, intervals, the permutation null, the Holm-adjusted primary cells.</li>
<li><a href="PROPOSALS.md">Round one</a> and <a href="PROPOSALS_BLIND.md">round two</a> of the proposer, with <a href="proposals_round1_prompt.txt">what it was shown</a> (<a href="proposals_round2_prompt.txt">blind</a>), <a href="proposals_round1_reply.txt">what it replied</a> (<a href="proposals_round2_reply.txt">blind</a>) and the ledgers (<a href="proposals_round1_ledger.jsonl">1</a>, <a href="proposals_round2_ledger.jsonl">2</a>).</li>
<li><a href="code.zip">The code</a>: the epoch gate, the pools, the forecasting, the claim grammar, the tests and the scripts. Point it at a folder of MuseLog CSV files and it rebuilds all of this in a few minutes.</li>
</ul>
<p class="foot">Nothing on this page is verified in the exact sense; the best a forecast or a proposed claim can earn is empirical, with its interval. The per-session tables the model saw are not published because their keys carry the recordings' names. The raw recordings stay with the people who made them.</p>
</div>
</body>
</html>
"""


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    summary = json.load(open(os.path.join(RES, "forecast", "summary.json"), encoding="utf-8"))
    rec = recording_level()
    open(os.path.join(out, "index.html"), "w", encoding="utf-8", newline="\n").write(render(summary, rec))
    for name in ("skill_by_horizon.svg", "skill_by_horizon_dark.svg", "skill_by_horizon.pdf"):
        shutil.copy(os.path.join(RES, "forecast", name), os.path.join(out, name))
    for name in ("FORECAST.md", "PROPOSALS.md", "PROPOSALS_BLIND.md"):
        shutil.copy(os.path.join(RES, name), os.path.join(out, name))
    open(os.path.join(out, "PREDICTIONS.md"), "w", encoding="utf-8", newline="\n").write(
        redacted(open(os.path.join(ROOT, "PREDICTIONS.md"), encoding="utf-8").read()))
    for round_, folder in (("round1", "proposals"), ("round2", "proposals_blind")):
        for src, dst in (("prompt.txt", f"proposals_{round_}_prompt.txt"), ("raw_reply.txt", f"proposals_{round_}_reply.txt"),
                         ("ledger.jsonl", f"proposals_{round_}_ledger.jsonl")):
            p = os.path.join(RES, folder, src)
            if os.path.exists(p):
                shutil.copy(p, os.path.join(out, dst))
    # the code, from the working tree, without results and with the redacted pre-registration
    with zipfile.ZipFile(os.path.join(out, "code.zip"), "w", zipfile.ZIP_DEFLATED) as z:
        for rel in ("README.md", ".gitignore"):
            z.write(os.path.join(ROOT, rel), f"eeg-anticipation/{rel}")
        z.writestr("eeg-anticipation/PREDICTIONS.md", redacted(open(os.path.join(ROOT, "PREDICTIONS.md"), encoding="utf-8").read()))
        for folder in ("src", "scripts", "tests"):
            for dp, dn, fn in os.walk(os.path.join(ROOT, folder)):
                dn[:] = [d for d in dn if d != "__pycache__"]
                for f in fn:
                    if f.endswith(".py"):
                        full = os.path.join(dp, f)
                        z.write(full, "eeg-anticipation/" + os.path.relpath(full, ROOT).replace(os.sep, "/"))
    # nothing published may carry another wearer's name or the raw tags
    bad = re.compile(r"ChanBefore|Chris|SARAH|GIA|LUCIA|MARIO|P\d{3}\b|tagged SM")
    for f in sorted(os.listdir(out)):
        if f.endswith((".html", ".md", ".txt", ".jsonl")):
            text = open(os.path.join(out, f), encoding="utf-8", errors="replace").read()
            m = bad.search(text)
            if m:
                sys.exit(f"REFUSING to publish: {f} contains {m.group(0)!r}")
    print("wrote", out, ":", ", ".join(sorted(os.listdir(out))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
