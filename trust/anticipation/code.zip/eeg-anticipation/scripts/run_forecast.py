"""Protocols A and B over the feature files, exactly as pre-registered. Writes results/forecast/records.json,
results/forecast/summary.json and results/FORECAST.md.

    python scripts/run_forecast.py [--pools mine,cold,all] [--no-gru] [--n-null 200]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))

from anticipate import forecast as F  # noqa: E402
from anticipate.epochs import Session  # noqa: E402

FEAT = os.path.join(ROOT, "results", "features")
OUT = os.path.join(ROOT, "results", "forecast")
PRIMARY = [("mine", "A", "ridge_all", 1), ("mine", "A", "ridge_all", 2), ("mine", "A", "ridge_all", 4),
           ("cold", "A", "ridge_all", 1), ("cold", "A", "ridge_all", 2), ("cold", "A", "ridge_all", 4)]


def load_sessions() -> dict[str, Session]:
    idx = json.load(open(os.path.join(FEAT, "index.json"), encoding="utf-8"))
    out = {}
    for key, info in idx.items():
        if "minutes" not in info or "skipped" in info or "failed" in info:
            continue
        s = Session.from_npz(os.path.join(FEAT, key + ".npz"))
        s.meta.update(info)
        s.meta["key"] = key
        out[key] = s
    return out


def split(s: F.Seqs, frac: float = 0.6):
    cut = int(frac * s.n)
    sl = lambda a, b: F.Seqs(s.stamp, s.X_last[a:b], s.X_seq[a:b], s.y[a:b], s.y_last[a:b], s.y_mean[a:b], s.t[a:b])  # noqa: E731
    return sl(0, cut), sl(cut, s.n)


def models(gru: bool) -> dict:
    m = {"ridge_lags": lambda: F.Ridge(columns=slice(0, F.K)), "ridge_all": lambda: F.Ridge()}
    if gru:
        m["gru"] = lambda: F.GRU(epochs=20, patience=4)
    return m


def baseline_rows(te: F.Seqs) -> dict:
    base = F.score(te, te.y_last)
    return {"persistence": dict(base, sse_model=base["sse_persist"]), "session_mean": dict(base, sse_model=base["sse_mean"])}


def protocol_a(pool_sessions: list[Session], horizons, with_gru=False):
    """Within each session, forward in time: first 60 % train, last 40 % test. Ridge only."""
    rows, tests = {}, {}
    for s in pool_sessions:
        for h in horizons:
            seq = F.build_sequences(s, h)
            if seq.n < F.MIN_SEQUENCES:
                continue
            tr, te = split(seq)
            for name, make in models(False).items():
                m = make().fit(tr)
                r = F.score(te, m.predict(te))
                r["key"] = s.meta["key"]
                rows.setdefault((name, h), []).append(r)
                tests.setdefault((name, h), []).append((te, m))
            for name, r in baseline_rows(te).items():
                r["key"] = s.meta["key"]
                rows.setdefault((name, h), []).append(r)
    return rows, tests


def _group_folds(keys, n_folds, seed=0):
    rng = np.random.default_rng(seed)
    keys = list(keys)
    rng.shuffle(keys)
    return [keys[i::n_folds] for i in range(n_folds)]


def protocol_b(pool_sessions: list[Session], horizons, loso: bool, with_gru: bool, test_sessions=None,
               label="B"):
    """Across sessions. Ridge: leave one session out (or 5 grouped folds when loso is False). GRU: 5 grouped folds.
    With test_sessions given (all -> mine): train once on pool_sessions, test on each test session."""
    rows, tests = {}, {}
    for h in horizons:
        seqs = {s.meta["key"]: F.build_sequences(s, h) for s in pool_sessions}
        seqs = {k: v for k, v in seqs.items() if v.n >= F.MIN_SEQUENCES}
        if test_sessions is not None:
            tseqs = {s.meta["key"]: F.build_sequences(s, h) for s in test_sessions}
            tseqs = {k: v for k, v in tseqs.items() if v.n >= F.MIN_SEQUENCES}
            folds = [list(tseqs)]
            train_for = {tuple(folds[0]): list(seqs)}
            pool = dict(seqs, **tseqs)
        else:
            pool = seqs
            keys = list(seqs)
            folds = [[k] for k in keys] if loso else _group_folds(keys, 5)
            train_for = {tuple(f): [k for k in keys if k not in set(f)] for f in folds}
        ridge_folds = folds
        gru_folds = folds if (test_sessions is not None or not loso) else _group_folds(list(seqs), 5)
        for name, make in models(False).items():
            for f in ridge_folds:
                tr = F.concat([pool[k] for k in train_for[tuple(f)]])
                if tr.n < F.MIN_SEQUENCES:
                    continue
                m = make().fit(tr)
                for k in f:
                    r = F.score(pool[k], m.predict(pool[k]))
                    r["key"] = k
                    rows.setdefault((name, h), []).append(r)
                    tests.setdefault((name, h), []).append((pool[k], m))
        for f in ridge_folds:
            for k in f:
                for name, r in baseline_rows(pool[k]).items():
                    r["key"] = k
                    rows.setdefault((name, h), []).append(r)
        if with_gru:
            for f in gru_folds:
                train_keys = train_for.get(tuple(f)) or [k for k in seqs if k not in set(f)]
                if len(train_keys) < 3:
                    continue
                val_keys = train_keys[:: max(1, len(train_keys) // 5)][:max(1, len(train_keys) // 10)]
                fit_keys = [k for k in train_keys if k not in set(val_keys)] or train_keys
                tr = F.concat([pool[k] for k in fit_keys])
                va = F.concat([pool[k] for k in val_keys])
                m = F.GRU(epochs=20, patience=4).fit(tr, val=va)
                for k in f:
                    r = F.score(pool[k], m.predict(pool[k]))
                    r["key"] = k
                    rows.setdefault(("gru", h), []).append(r)
    return rows, tests


def aggregate(rows, tests, n_null, null_cells):
    out = {}
    for (name, h), rs in rows.items():
        cell = {"persist": F.bootstrap(rs), "mean": F.bootstrap(rs, against="sse_mean")}
        if (name, h) in null_cells and (name, h) in tests:
            cell["p_null"] = F.null_pvalue(tests[(name, h)], cell["persist"]["pooled"], n_null=n_null)
        out[f"{name}@{h}"] = cell
    return out


def coverage(pool_sessions):
    uf = np.array([s.usable_fraction for s in pool_sessions])
    return {"sessions": int(len(uf)), "usable_fraction_mean": float(uf.mean()) if len(uf) else float("nan"),
            "usable_fraction_median": float(np.median(uf)) if len(uf) else float("nan"),
            "minutes": float(sum(s.duration_s for s in pool_sessions) / 60)}


def eligible(s: Session) -> bool:
    return F.build_sequences(s, 1).n >= F.MIN_SEQUENCES


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pools", default="mine,cold,all")
    ap.add_argument("--no-gru", action="store_true")
    ap.add_argument("--n-null", type=int, default=F.N_NULL)
    a = ap.parse_args()
    t0 = time.time()
    os.makedirs(OUT, exist_ok=True)
    sessions = load_sessions()
    by_pool = {p: [s for s in sessions.values() if p in s.meta.get("pools", []) and eligible(s)]
               for p in ("mine", "cold", "all", "mine_sleep")}
    mine_keys = {s.meta["key"] for s in by_pool["mine"]} | {s.meta["key"] for s in by_pool["mine_sleep"]}
    print({p: len(v) for p, v in by_pool.items()}, "eligible sessions;", len(sessions), "with features")
    summary = {"pools": {p: coverage(v) for p, v in by_pool.items()}, "cells": {}, "settings": vars(a),
               "features_index": os.path.relpath(os.path.join(FEAT, "index.json"), ROOT)}
    records = {}
    horizons = list(F.HORIZONS)
    gru = not a.no_gru
    for pool in a.pools.split(","):
        ps = by_pool[pool]
        if not ps:
            continue
        print(f"[{pool}] protocol A on {len(ps)} sessions", flush=True)
        rows, tests = protocol_a(ps, horizons)
        null_cells = {("ridge_all", h) for (pp, proto, mm, h) in PRIMARY if pp == pool and proto == "A"} | {("ridge_lags", 1)}
        summary["cells"][f"{pool}/A"] = aggregate(rows, tests, a.n_null, null_cells)
        records[f"{pool}/A"] = {f"{k[0]}@{k[1]}": v for k, v in rows.items()}
        print(f"[{pool}] protocol B on {len(ps)} sessions (loso={pool != 'all'}, gru={gru})", flush=True)
        rows, tests = protocol_b(ps, horizons, loso=(pool != "all"), with_gru=gru)
        summary["cells"][f"{pool}/B"] = aggregate(rows, tests, a.n_null, {("ridge_all", 1)})
        records[f"{pool}/B"] = {f"{k[0]}@{k[1]}": v for k, v in rows.items()}
        print(f"[{pool}] done at {time.time() - t0:.0f}s", flush=True)
    if "mine" in a.pools.split(",") and by_pool["mine"]:
        others = [s for s in by_pool["all"] if s.meta["key"] not in mine_keys]
        print(f"[all->mine] train on {len(others)} other sessions, test on {len(by_pool['mine'])}", flush=True)
        rows, tests = protocol_b(others, horizons, loso=False, with_gru=gru, test_sessions=by_pool["mine"])
        summary["cells"]["all->mine"] = aggregate(rows, tests, a.n_null, {("ridge_all", 1)})
        records["all->mine"] = {f"{k[0]}@{k[1]}": v for k, v in rows.items()}
    if by_pool["mine_sleep"]:
        rows, tests = protocol_a(by_pool["mine_sleep"], horizons)
        summary["cells"]["mine_sleep/A"] = aggregate(rows, tests, a.n_null, set())
        records["mine_sleep/A"] = {f"{k[0]}@{k[1]}": v for k, v in rows.items()}
    # Holm across the six primary cells
    pv = {}
    for pool, proto, model, h in PRIMARY:
        cell = summary["cells"].get(f"{pool}/{proto}", {}).get(f"{model}@{h}")
        if cell and "p_null" in cell:
            pv[f"{pool}/{proto}/{model}@{h}"] = cell["p_null"]
    summary["holm_primary"] = F.holm(pv)
    summary["predictions"] = verdicts(summary)
    summary["seconds"] = round(time.time() - t0)
    json.dump(summary, open(os.path.join(OUT, "summary.json"), "w", encoding="utf-8"), indent=1)
    json.dump(records, open(os.path.join(OUT, "records.json"), "w", encoding="utf-8"))
    open(os.path.join(ROOT, "results", "FORECAST.md"), "w", encoding="utf-8").write(report(summary))
    print(f"wrote results/FORECAST.md in {time.time() - t0:.0f}s")
    return 0


def _cell(summary, key, model, h, against="persist"):
    c = summary["cells"].get(key, {}).get(f"{model}@{h}")
    return c[against] if c else None


def verdicts(summary) -> dict:
    out = {}
    g = lambda key, model, h, against="persist": _cell(summary, key, model, h, against)  # noqa: E731
    c = g("mine/A", "ridge_all", 1)
    out["P1"] = {"claim": "mine, A, ridge_all, h=1: pooled skill over persistence in [0.05, 0.30], interval excludes 0",
                 "value": c and c["pooled"], "ci": c and c["pooled_ci"],
                 "supported": bool(c and 0.05 <= c["pooled"] <= 0.30 and c["pooled_ci"][0] > 0)}
    p2 = {}
    for pool in ("mine", "cold", "all"):
        vals = [g(f"{pool}/A", "ridge_all", h, "mean") for h in F.HORIZONS]
        if all(vals):
            sk = [v["pooled"] for v in vals]
            p2[pool] = {"skill_vs_mean": sk, "decreasing": all(x >= y - 1e-9 for x, y in zip(sk, sk[1:])), "h8_le_0.05": sk[-1] <= 0.05}
    out["P2"] = {"claim": "skill against the session mean falls with horizon and is <= 0.05 at h=8, every pool",
                 "by_pool": p2, "supported": bool(p2) and all(v["decreasing"] and v["h8_le_0.05"] for v in p2.values())}
    p3 = {}
    for pool in ("mine", "cold", "all"):
        for h in F.HORIZONS:
            gr, ra = g(f"{pool}/B", "gru", h), g(f"{pool}/B", "ridge_all", h)
            if gr and ra:
                p3[f"{pool}@{h}"] = round(gr["pooled"] - ra["pooled"], 4)
    out["P3"] = {"claim": "GRU never beats ridge_all by more than 0.05 pooled skill (protocol B)", "gru_minus_ridge": p3,
                 "supported": bool(p3) and max(p3.values()) <= 0.05}
    p4 = {}
    for pool in ("mine", "cold"):
        a1, b1 = g(f"{pool}/A", "ridge_all", 1), g(f"{pool}/B", "ridge_all", 1)
        if a1 and b1:
            p4[pool] = round(b1["pooled"] - a1["pooled"], 4)
    out["P4"] = {"claim": "cross-session ridge (B) exceeds within-session ridge (A) at h=1 by at most 0.03", "b_minus_a": p4,
                 "supported": bool(p4) and max(p4.values()) <= 0.03}
    am, bm = g("all->mine", "ridge_all", 1), g("mine/B", "ridge_all", 1)
    out["P5"] = {"claim": "all->mine ridge_all at h=1 within 0.05 of B-within-mine", "all_to_mine": am and am["pooled"],
                 "within_mine": bm and bm["pooled"], "supported": bool(am and bm and abs(am["pooled"] - bm["pooled"]) <= 0.05)}
    cm, mm = g("cold/A", "ridge_all", 1), g("mine/A", "ridge_all", 1)
    out["P6"] = {"claim": "cold pool pooled skill at h=1 within 0.10 of mine", "cold": cm and cm["pooled"], "mine": mm and mm["pooled"],
                 "supported": bool(cm and mm and abs(cm["pooled"] - mm["pooled"]) <= 0.10)}
    pc, pm = summary["pools"].get("cold"), summary["pools"].get("mine")
    out["P7"] = {"claim": "usable fraction (mean) in cold is lower than in mine by at least 0.15",
                 "cold": pc and pc["usable_fraction_mean"], "mine": pm and pm["usable_fraction_mean"],
                 "supported": bool(pc and pm and pm["usable_fraction_mean"] - pc["usable_fraction_mean"] >= 0.15)}
    return out


def _fmt(c):
    if not c:
        return "·"
    return f"{c['pooled']:+.3f} [{c['pooled_ci'][0]:+.3f}, {c['pooled_ci'][1]:+.3f}] · med {c['median']:+.3f} · +{100 * c['share_positive']:.0f}% · n={c['sessions']}"


def report(summary) -> str:
    L = ["# Forecasting the activation index: results", "",
         "Skill = 1 − MSE(model)/MSE(baseline), pooled over sessions, with a 95 % interval from 2000 session bootstraps, "
         "the median per-session skill, the share of sessions with positive skill, and the number of sessions. "
         "Horizons in epochs of 2 s. Everything as pre-registered in PREDICTIONS.md (with its two amendments).", ""]
    L.append("## Pools")
    L.append("")
    L.append("| pool | eligible sessions | minutes | usable fraction, mean | median |")
    L.append("|---|---|---|---|---|")
    for p, c in summary["pools"].items():
        L.append(f"| {p} | {c['sessions']} | {c['minutes']:.0f} | {c['usable_fraction_mean']:.2f} | {c['usable_fraction_median']:.2f} |")
    L.append("")
    for key, cells in summary["cells"].items():
        L.append(f"## {key}")
        L.append("")
        for against, title in (("persist", "against persistence"), ("mean", "against the session mean")):
            L.append(f"**{title}**")
            L.append("")
            L.append("| model | " + " | ".join(f"h={h} ({2 * h} s)" for h in F.HORIZONS) + " |")
            L.append("|---|" + "---|" * len(F.HORIZONS))
            names = sorted({k.split("@")[0] for k in cells})
            order = [n for n in ("persistence", "session_mean", "ridge_lags", "ridge_all", "gru") if n in names]
            for name in order:
                if (against == "persist" and name == "persistence") or (against == "mean" and name == "session_mean"):
                    continue
                L.append(f"| {name} | " + " | ".join(_fmt((cells.get(f'{name}@{h}') or {}).get(against)) for h in F.HORIZONS) + " |")
            L.append("")
        ps = {k: v["p_null"] for k, v in cells.items() if "p_null" in v}
        if ps:
            L.append("Permutation null (older history shuffled, current value kept): " + ", ".join(f"{k}: p = {v:.3f}" for k, v in sorted(ps.items())))
            L.append("")
    if summary.get("holm_primary"):
        L.append("## Primary cells, Holm-adjusted p")
        L.append("")
        for k, v in summary["holm_primary"].items():
            L.append(f"- {k}: {v:.3f}")
        L.append("")
    L.append("## Predictions")
    L.append("")
    for k, v in summary["predictions"].items():
        L.append(f"- **{k}** {'SUPPORTED' if v['supported'] else 'REFUTED'}: {v['claim']}. " + json.dumps({kk: vv for kk, vv in v.items() if kk not in ('claim', 'supported')}, default=float)[:400])
    L.append("")
    L.append(f"Run time {summary.get('seconds', '?')} s.")
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    sys.exit(main())
