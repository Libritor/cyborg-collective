"""The results figure: pooled skill against horizon, one line per pool, small multiples by protocol and baseline.

Form: change over an ordered axis -> lines; three series in a fixed categorical order (mine, cold, all) with a
legend and direct end labels; 95 % intervals as thin vertical whiskers; one y axis shared by all panels; hairline
solid grid; text in text tokens, never in a series colour. Light and dark renders; PDF with embedded text (Type 42).

    python scripts/make_figure.py            -> results/forecast/skill_by_horizon{,_dark}.{svg,pdf,png}
"""
from __future__ import annotations

import json
import os
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "results", "forecast")
HORIZONS = [1, 2, 4, 8]
SERIES = ["mine", "cold", "all"]                       # fixed categorical order; colour follows the pool, never its rank
THEMES = {
    "light": {"surface": "#fcfcfb", "text": "#0b0b0b", "text2": "#52514e", "grid": "#e8e7e3", "zero": "#b8b7b1",
              "colors": {"mine": "#2a78d6", "cold": "#eb6834", "all": "#1baf7a"}},
    "dark": {"surface": "#1a1a19", "text": "#f0efec", "text2": "#c3c2b7", "grid": "#2f2f2d", "zero": "#4a4a47",
             "colors": {"mine": "#3987e5", "cold": "#d95926", "all": "#199e70"}},
}
PANELS = [("mine/A|cold/A|all/A", "persist", "Within a session, forward in time (A)", "skill against persistence"),
          ("mine/A|cold/A|all/A", "mean", "Within a session, forward in time (A)", "skill against the session mean"),
          ("mine/B|cold/B|all/B", "persist", "Across sessions, held out (B)", "skill against persistence"),
          ("mine/B|cold/B|all/B", "mean", "Across sessions, held out (B)", "skill against the session mean")]
MODEL = "ridge_all"


def cell(summary, key, h, against):
    c = summary["cells"].get(key, {}).get(f"{MODEL}@{h}")
    return c[against] if c else None


def draw(summary, theme: str):
    t = THEMES[theme]
    plt.rcParams.update({"pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none", "font.family": "DejaVu Sans",
                         "font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9, "xtick.labelsize": 8.5,
                         "ytick.labelsize": 8.5, "legend.fontsize": 8.5, "text.color": t["text"],
                         "axes.labelcolor": t["text2"], "xtick.color": t["text2"], "ytick.color": t["text2"],
                         "axes.edgecolor": t["grid"], "figure.facecolor": t["surface"], "axes.facecolor": t["surface"],
                         "savefig.facecolor": t["surface"]})
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.4), sharex=True, sharey=True)
    YLO, YHI = -0.6, 0.65                               # the axis stays readable; anything beyond is marked, not hidden
    for ax, (keys, against, title, ylabel) in zip(axes.ravel(), PANELS):
        ax.grid(True, axis="y", color=t["grid"], linewidth=0.8, linestyle="-")
        ax.axhline(0, color=t["zero"], linewidth=1.0, zorder=1)
        ends = []
        for si, (pool, key) in enumerate(zip(SERIES, keys.split("|"))):
            pts = [(h, cell(summary, key, h, against)) for h in HORIZONS]
            pts = [(h, c) for h, c in pts if c]
            if not pts:
                continue
            dx = (si - 1) * 0.06                         # a small dodge so whiskers never overprint
            xs = [h * (1 + dx) for h, _ in pts]
            ys = [c["pooled"] for _, c in pts]
            col = t["colors"][pool]
            for x, y, (_, c) in zip(xs, ys, pts):
                lo, hi = c["pooled_ci"]
                ax.plot([x, x], [max(lo, YLO), min(hi, YHI)], color=col, linewidth=1.0, solid_capstyle="butt", zorder=2)
                if y < YLO:                              # off the scale: a hollow marker at the edge and the value
                    ax.scatter([x], [YLO + 0.02], s=36, facecolors=t["surface"], edgecolors=col, linewidths=1.5, zorder=4)
                    ax.annotate(f"{y:+.2f}: off the scale, one session\nof {c['sessions']} is far off (see the table)", (x, YLO + 0.02),
                                xytext=(9, 1), textcoords="offset points", fontsize=7, color=t["text2"], va="bottom",
                                bbox=dict(facecolor=t["surface"], edgecolor="none", pad=1.5), zorder=6)
            ys_plot = [min(max(y, YLO + 0.02), YHI) for y in ys]
            ax.plot(xs, ys_plot, color=col, linewidth=2.0, solid_joinstyle="round", solid_capstyle="round", zorder=3,
                    label=f"{pool} ({pts[0][1]['sessions']} sessions)")
            on = [(x, y) for x, y in zip(xs, ys) if YLO <= y <= YHI]
            if on:
                ax.scatter([x for x, _ in on], [y for _, y in on], s=36, color=col, edgecolors=t["surface"],
                           linewidths=2.0, zorder=4)
            ends.append((ys_plot[-1], xs[-1], pool))
        # direct end labels, pushed apart so they never overprint (identity is also in the legend)
        ends.sort()
        placed = []
        for y, x, pool in ends:
            while placed and y - placed[-1] < 0.075:
                y = placed[-1] + 0.075
            placed.append(y)
            ax.annotate(pool, (x, y), xytext=(7, 0), textcoords="offset points", va="center", fontsize=8.5, color=t["text"])
        ax.set_xscale("log", base=2)
        ax.set_xticks(HORIZONS)
        ax.set_xticklabels([f"{2 * h} s" for h in HORIZONS])
        ax.minorticks_off()
        ax.set_title(title, loc="left", color=t["text"])
        ax.set_ylabel(ylabel, color=t["text2"])
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
        ax.tick_params(length=0)
    axes[0, 0].set_ylim(YLO, YHI)
    axes[0, 0].set_xlim(HORIZONS[0] * 0.85, HORIZONS[-1] * 1.5)
    for ax in axes[1]:
        ax.set_xlabel("how far ahead")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, frameon=False, bbox_to_anchor=(0.5, -0.01))
    fig.suptitle("Forecasting the activation index of a Muse headband: ridge on 16 s of history, pooled skill with "
                 "95 % session-bootstrap intervals", x=0.01, ha="left", fontsize=9.5, color=t["text"])
    fig.tight_layout(rect=(0, 0.05, 1, 0.96))
    return fig


FONT_STACK = "system-ui, -apple-system, 'Segoe UI', Roboto, 'DejaVu Sans', sans-serif"


def web_fonts(svg_path: str) -> None:
    """The SVG keeps its text as text; name a font stack a browser can resolve instead of the one matplotlib found."""
    import re
    s = open(svg_path, encoding="utf-8").read()
    s = re.sub(r"font-family:\s*'?DejaVu Sans'?", "font-family: " + FONT_STACK, s)
    s = re.sub(r"(font:\s*[^;\"']*?)'DejaVu Sans'", r"\1" + FONT_STACK, s)
    open(svg_path, "w", encoding="utf-8", newline="\n").write(s)


def main() -> int:
    summary = json.load(open(os.path.join(OUT, "summary.json"), encoding="utf-8"))
    for theme in THEMES:
        fig = draw(summary, theme)
        suffix = "" if theme == "light" else "_dark"
        for ext in ("svg", "pdf", "png"):
            fig.savefig(os.path.join(OUT, f"skill_by_horizon{suffix}.{ext}"), dpi=200 if ext == "png" else None,
                        bbox_inches="tight")
        web_fonts(os.path.join(OUT, f"skill_by_horizon{suffix}.svg"))
        plt.close(fig)
        print("wrote", f"skill_by_horizon{suffix}.{{svg,pdf,png}}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
