# EEG anticipation, gated

How far ahead can a Muse headband's EEG be predicted, on one person's own head and on the lab's cold-exposure recordings, when every number must pass the same gates the lab's papers use. Pre-registered in `PREDICTIONS.md` before the first run (two amendments, also before the first run, are recorded there).

Everything runs on the laptop. The raw recordings never leave it; the local language model (Ornith 9B through Ollama) only ever sees aggregate tables.

    python -m pytest tests -q                       # the gates and metrics on synthetic data (14 tests)
    python scripts/build_features.py                 # MuseLog CSV -> gated 2 s epochs, results/features/ (not committed)
    python scripts/run_forecast.py                   # protocols A and B, results/forecast/ + results/FORECAST.md
    python scripts/make_figure.py                    # results/forecast/skill_by_horizon{,_dark}.{svg,pdf,png}
    python scripts/propose.py                        # Ornith proposes claims, the gate disposes, results/PROPOSALS.md
    python scripts/propose.py --blind --name blind   # the same with the forecast numbers withheld, results/PROPOSALS_BLIND.md

Read `results/RESULTS.md` first: it is the honest reading of everything below it.

Layout: `src/anticipate/epochs.py` (the epoch gate and band powers), `pools.py` (which recordings belong to which pool, from filename stamps and folders), `forecast.py` (sequences, models, splits, skill, bootstrap, the permutation null, Holm), `claims.py` (the claim grammar and its tests).

Memory: set `OPENBLAS_NUM_THREADS=2` on this laptop before the runs, and unload the language model from Ollama while forecasting (its mapped memory counts against the commit limit and starved OpenBLAS once).

Privacy: the session keys in `results/forecast/records.json` and `results/proposals*/session_table.json` are the recordings' filename stamps and tags, and some tags carry a wearer's first name. This repository is local. Pseudonymise those keys before publishing any of it.

Honest scope: skill is measured against persistence and against the session mean on held-out time or held-out sessions. "Verified" is never used here; the best a forecast or a proposed claim can earn is "empirical, with its interval".
