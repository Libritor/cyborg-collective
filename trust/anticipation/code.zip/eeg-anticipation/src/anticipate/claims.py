"""The claim grammar and its gates: a local language model proposes, a permutation test or a held-out forecast
result disposes. Nothing here can mint more than "supported (empirical)".

A claim is one of
  {"type": "compare_groups", "stat": S, "group_a": G, "group_b": G, "direction": ">" | "<"}
  {"type": "correlation", "x": S, "y": S, "pool": P, "sign": "+" | "-"}
  {"type": "forecast", "pool": P, "protocol": "A" | "B", "model": M, "horizon": 1|2|4|8, "min_skill": float}
where S is a session statistic from STATS, G = {"pool": P, "condition": C}, P in POOLS, C in CONDITIONS.
Outcomes: supported, refuted, not_supported, abstain (underpowered or no such cell), malformed.
"""
from __future__ import annotations

import numpy as np

STATS = ["minutes", "usable_fraction", "mean_index", "sd_index", "mean_logalpha", "mean_logtheta", "mean_logbeta",
         "mean_loggamma", "gyro_rms_mean", "skill_A_h1", "skill_A_h4", "skill_mean_A_h1"]
POOLS = ["mine", "cold", "all", "mine_sleep"]
CONDITIONS = ["any", "pre", "post", "warm", "cold", "sleep", "unlabelled"]
MODELS = ["ridge_lags", "ridge_all", "gru"]
HORIZONS = [1, 2, 4, 8]
MIN_GROUP = 5
MIN_CORR = 10
N_PERM = 10000
ALPHA = 0.05


def _match(row: dict, group: dict) -> bool:
    pool = group.get("pool", "all")
    cond = group.get("condition", "any")
    if pool not in row.get("pools", []):
        return False
    c = row.get("condition") or "unlabelled"
    return cond == "any" or c == cond


def _vals(rows, stat):
    v = np.array([r.get(stat, np.nan) for r in rows], dtype=float)
    return v[np.isfinite(v)]


def validate(claim: dict) -> str | None:
    """None when well formed, else the reason it is malformed."""
    t = claim.get("type")
    if t == "compare_groups":
        if claim.get("stat") not in STATS:
            return f"unknown stat {claim.get('stat')!r}"
        for g in ("group_a", "group_b"):
            grp = claim.get(g)
            if not isinstance(grp, dict) or grp.get("pool", "all") not in POOLS or grp.get("condition", "any") not in CONDITIONS:
                return f"bad {g}"
        if claim.get("direction") not in (">", "<"):
            return "direction must be > or <"
        if claim["group_a"] == claim["group_b"]:
            return "the two groups are the same"
        return None
    if t == "correlation":
        if claim.get("x") not in STATS or claim.get("y") not in STATS or claim.get("x") == claim.get("y"):
            return "x and y must be two different stats"
        if claim.get("pool", "all") not in POOLS or claim.get("sign") not in ("+", "-"):
            return "bad pool or sign"
        return None
    if t == "forecast":
        if claim.get("pool") not in POOLS or claim.get("protocol", "A") not in ("A", "B") or claim.get("model") not in MODELS:
            return "bad pool, protocol or model"
        if claim.get("horizon") not in HORIZONS:
            return "horizon must be 1, 2, 4 or 8"
        try:
            float(claim.get("min_skill"))
        except (TypeError, ValueError):
            return "min_skill must be a number"
        return None
    return f"unknown type {t!r}"


def perm_diff(a: np.ndarray, b: np.ndarray, direction: str, n_perm: int = N_PERM, seed: int = 0) -> dict:
    """One-sided permutation test on the difference of means, both directions reported."""
    rng = np.random.default_rng(seed)
    obs = float(a.mean() - b.mean())
    pooled = np.concatenate([a, b])
    na = len(a)
    diffs = np.empty(n_perm)
    for i in range(n_perm):
        rng.shuffle(pooled)
        diffs[i] = pooled[:na].mean() - pooled[na:].mean()
    p_gt = float((np.sum(diffs >= obs) + 1) / (n_perm + 1))
    p_lt = float((np.sum(diffs <= obs) + 1) / (n_perm + 1))
    # Cliff's delta
    gt = sum(np.sum(x > b) for x in a)
    lt = sum(np.sum(x < b) for x in a)
    delta = float((gt - lt) / (len(a) * len(b)))
    p_stated = p_gt if direction == ">" else p_lt
    p_opposite = p_lt if direction == ">" else p_gt
    return {"difference": obs, "cliffs_delta": delta, "p_stated": p_stated, "p_opposite": p_opposite,
            "n_a": int(len(a)), "n_b": int(len(b))}


def perm_spearman(x: np.ndarray, y: np.ndarray, sign: str, n_perm: int = N_PERM, seed: int = 0) -> dict:
    from scipy.stats import rankdata
    rng = np.random.default_rng(seed)
    rx, ry = rankdata(x), rankdata(y)
    rho = float(np.corrcoef(rx, ry)[0, 1])
    rhos = np.empty(n_perm)
    ry2 = ry.copy()
    for i in range(n_perm):
        rng.shuffle(ry2)
        rhos[i] = np.corrcoef(rx, ry2)[0, 1]
    p_pos = float((np.sum(rhos >= rho) + 1) / (n_perm + 1))
    p_neg = float((np.sum(rhos <= rho) + 1) / (n_perm + 1))
    return {"rho": rho, "p_stated": p_pos if sign == "+" else p_neg, "p_opposite": p_neg if sign == "+" else p_pos, "n": int(len(x))}


def test_claim(claim: dict, table: list[dict], forecast_summary: dict | None) -> dict:
    """The gate for one claim. Returns the outcome before Holm (p values raw); decide() applies the correction."""
    bad = validate(claim)
    if bad:
        return {"outcome": "malformed", "reason": bad}
    t = claim["type"]
    if t == "compare_groups":
        A = [r for r in table if _match(r, claim["group_a"])]
        B = [r for r in table if _match(r, claim["group_b"])]
        keys_a, keys_b = {r["key"] for r in A}, {r["key"] for r in B}
        if keys_a & keys_b:
            return {"outcome": "malformed", "reason": f"groups overlap on {len(keys_a & keys_b)} sessions"}
        a, b = _vals(A, claim["stat"]), _vals(B, claim["stat"])
        if len(a) < MIN_GROUP or len(b) < MIN_GROUP:
            return {"outcome": "abstain", "reason": f"underpowered: n_a={len(a)}, n_b={len(b)} (need {MIN_GROUP} each)"}
        return {"outcome": "tested", **perm_diff(a, b, claim["direction"])}
    if t == "correlation":
        R = [r for r in table if claim.get("pool", "all") in r.get("pools", [])]
        pairs = np.array([(r.get(claim["x"], np.nan), r.get(claim["y"], np.nan)) for r in R], dtype=float)
        if len(pairs):
            pairs = pairs[np.isfinite(pairs).all(axis=1)]
        if len(pairs) < MIN_CORR:
            return {"outcome": "abstain", "reason": f"underpowered: n={len(pairs)} (need {MIN_CORR})"}
        return {"outcome": "tested", **perm_spearman(pairs[:, 0], pairs[:, 1], claim["sign"])}
    if t == "forecast":
        key = f"{claim['pool']}/{claim.get('protocol', 'A')}"
        cell = (forecast_summary or {}).get("cells", {}).get(key, {}).get(f"{claim['model']}@{claim['horizon']}")
        if not cell:
            return {"outcome": "abstain", "reason": f"no forecast cell {key} {claim['model']}@{claim['horizon']}"}
        c = cell["persist"]
        lo, hi = c["pooled_ci"]
        m = float(claim["min_skill"])
        if c["pooled"] >= m and lo > 0:
            out = "supported"
        elif hi < m:
            out = "refuted"
        else:
            out = "not_supported"
        return {"outcome": out, "pooled_skill": c["pooled"], "ci": c["pooled_ci"], "sessions": c["sessions"], "min_skill": m}
    return {"outcome": "malformed", "reason": "unreachable"}


def decide(results: list[dict], alpha: float = ALPHA) -> list[dict]:
    """Holm across every tested claim's stated-direction p (and separately the opposite direction), then the outcome."""
    from .forecast import holm
    tested = [i for i, r in enumerate(results) if r.get("outcome") == "tested"]
    p_st = holm({str(i): results[i]["p_stated"] for i in tested})
    p_op = holm({str(i): results[i]["p_opposite"] for i in tested})
    out = []
    for i, r in enumerate(results):
        r = dict(r)
        if r.get("outcome") == "tested":
            r["p_stated_holm"] = p_st[str(i)]
            r["p_opposite_holm"] = p_op[str(i)]
            if r["p_stated_holm"] < alpha:
                r["outcome"] = "supported"
            elif r["p_opposite_holm"] < alpha:
                r["outcome"] = "refuted"
            else:
                r["outcome"] = "not_supported"
        out.append(r)
    return out


TIER = {"supported": "empirical", "refuted": "refuted", "not_supported": "inconclusive at this n",
        "abstain": "abstain", "malformed": "malformed"}
