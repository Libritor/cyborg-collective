"""Which recordings belong to which pool, from the filename stamp and the folder. Nothing is chosen by its results.

A recording is a MuseLog CSV named muse_session_YYYYMMDD_HHMMSS_<tag>.csv. The same file can sit in several folders
(a backup, Downloads, a scratch folder); the first copy found in FOLDER order is used.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass

STAMP_RX = re.compile(r"muse_session_(\d{8})_(\d{6})_(.+)\.csv$", re.IGNORECASE)

FOLDERS = [
    r"C:\Users\alexa\MuseLog_phone_backup_20260930\files\muse_sessions",
    r"C:\Users\alexa\MuseLog_phone_backup_20261027\muse_sessions",
    r"C:\Users\alexa\SnowballArcade\data\muselog",
    r"C:\Users\alexa\JobbingOnTheSleep\data\muselog",
    r"C:\Users\alexa\.gemini\antigravity\scratch",
    r"C:\Users\alexa\.gemini\antigravity\scratch\mar-2\pre-CWI Cognitive Assessments",
    r"C:\Users\alexa\Downloads",
]

# the owner's own head, by his own tagging (projects.json of the Collective page and the filenames)
MINE_WINDOWS = [("20251201", "20260115")]             # recorder-building period, Muse1 only
MINE_STAMPS = {"20260225_135128", "20261104_053232"}  # AlexBefore; the Nov 4 table session
MINE_SLEEP_STAMPS = {"20261027_012222"}               # the kept overnight share
COLD_WINDOWS = [("20260116", "20260131"), ("20260201", "20260331"), ("20261022", "20261023")]
# the two Buzzkill sittings of 22 and 23 October are "one author" in the paper; their Drive copies are tagged SM
NOT_MINE_TAG_RX = re.compile(r"chris|chan|muse[234]|P\d{3}|sarah|gia|lucia|mario", re.IGNORECASE)


@dataclass(frozen=True)
class Recording:
    path: str
    stamp: str        # YYYYMMDD_HHMMSS
    date: str         # YYYYMMDD
    tag: str          # Muse1, AlexBefore, ...
    folder: str
    pools: tuple      # subset of ("mine", "mine_sleep", "cold", "all")
    condition: str    # pre / post / warm / cold / sleep / "" from the filename, nothing inferred

    @property
    def key(self) -> str:
        return f"{self.stamp}_{self.tag}"


def _condition(tag: str, date: str) -> str:
    low = tag.lower()
    if "before" in low or "pre" in low:
        return "pre"
    if "after" in low or "post" in low:
        return "post"
    if date == "20261023":
        return "cold"
    if date == "20261022":
        return "warm"
    return ""


def classify(path: str) -> Recording | None:
    m = STAMP_RX.search(os.path.basename(path))
    if not m:
        return None
    date, clock, tag = m.group(1), m.group(2), m.group(3)
    stamp = f"{date}_{clock}"
    pools = ["all"]
    mine = False
    if stamp in MINE_STAMPS:
        mine = True
    for lo, hi in MINE_WINDOWS:
        if lo <= date <= hi and tag.lower() == "muse1":
            mine = True
    if mine and not NOT_MINE_TAG_RX.search(tag):
        pools.append("mine")
    if stamp in MINE_SLEEP_STAMPS:
        pools.append("mine_sleep")
    for lo, hi in COLD_WINDOWS:
        if lo <= date <= hi:
            pools.append("cold")
            break
    cond = _condition(tag, date)
    if stamp in MINE_SLEEP_STAMPS:
        cond = "sleep"
    return Recording(path=path, stamp=stamp, date=date, tag=tag, folder=os.path.dirname(path), pools=tuple(pools),
                     condition=cond)


def discover(folders=None) -> list[Recording]:
    seen: dict[str, Recording] = {}
    for folder in folders or FOLDERS:
        if not os.path.isdir(folder):
            continue
        for name in sorted(os.listdir(folder)):
            p = os.path.join(folder, name)
            if not os.path.isfile(p):
                continue
            r = classify(p)
            if r is None or r.key in seen:
                continue
            seen[r.key] = r
    return sorted(seen.values(), key=lambda r: r.stamp)
