"""MuseLog CSV -> gated 2 s epochs with band powers.

The gate is the one in the Buzzkill paper's analysis (SnowballArcade/Tools/cold_sessions_analysis.py): a channel's
epoch is accepted when its contact value (HSI) is 2 or better, its peak-to-peak swing is under 200 uV and at least
90 % of the samples arrived. An epoch is usable when at least two channels are accepted. Band powers by Welch.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy.signal import detrend, welch

FS = 256.0
EPOCH_S = 2.0
N_EPOCH = int(FS * EPOCH_S)          # 512 samples
MIN_SAMPLES = int(0.9 * N_EPOCH)     # 460: the gap gate
PP_MAX_UV = 200.0
HSI_OK = 2
CH = ["TP9", "AF7", "AF8", "TP10"]
BANDS = {"theta": (4.0, 8.0), "alpha": (8.0, 13.0), "beta": (13.0, 30.0), "gamma": (30.0, 44.0)}
BAND_NAMES = list(BANDS)


@dataclass
class Session:
    path: str
    stamp: str
    device: str
    t: np.ndarray                  # epoch start, seconds since the recording began
    accepted: np.ndarray           # (n_epochs, 4) bool, per channel
    usable: np.ndarray             # (n_epochs,) bool: >= 2 channels accepted
    logband: np.ndarray            # (n_epochs, 4 channels, 4 bands) log10 power, NaN where not accepted
    index: np.ndarray              # (n_epochs,) activation index over accepted channels, NaN where not usable
    logalpha: np.ndarray           # (n_epochs,) mean log alpha over accepted channels
    gyro_rms: np.ndarray           # (n_epochs,) RMS of the gyroscope norm, NaN when no gyro rows
    pp_uv: np.ndarray              # (n_epochs, 4) peak-to-peak per channel
    hsi: np.ndarray                # (n_epochs, 4) median HSI per channel (0 = unknown)
    n_samples: np.ndarray          # (n_epochs,) samples that arrived
    meta: dict = field(default_factory=dict)

    @property
    def n_epochs(self) -> int:
        return int(len(self.t))

    @property
    def usable_fraction(self) -> float:
        return float(self.usable.mean()) if self.n_epochs else 0.0

    @property
    def duration_s(self) -> float:
        return float(self.t[-1] + EPOCH_S) if self.n_epochs else 0.0

    def to_npz(self, path: str) -> None:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        np.savez_compressed(path, t=self.t, accepted=self.accepted, usable=self.usable, logband=self.logband,
                            index=self.index, logalpha=self.logalpha, gyro_rms=self.gyro_rms, pp_uv=self.pp_uv,
                            hsi=self.hsi, n_samples=self.n_samples,
                            meta=np.array([__import__("json").dumps(dict(self.meta, path=self.path, stamp=self.stamp,
                                                                          device=self.device))]))

    @staticmethod
    def from_npz(path: str) -> "Session":
        import json
        z = np.load(path, allow_pickle=False)
        meta = json.loads(str(z["meta"][0]))
        return Session(path=meta.pop("path"), stamp=meta.pop("stamp"), device=meta.pop("device"), t=z["t"],
                       accepted=z["accepted"], usable=z["usable"], logband=z["logband"], index=z["index"],
                       logalpha=z["logalpha"], gyro_rms=z["gyro_rms"], pp_uv=z["pp_uv"], hsi=z["hsi"],
                       n_samples=z["n_samples"], meta=meta)


def _columns(path: str) -> list[str]:
    return list(pd.read_csv(path, nrows=0).columns)


def load_raw(path: str) -> tuple[pd.DataFrame, dict]:
    """The columns the gate needs, as floats; ms_ELAPSED is the clock."""
    cols = _columns(path)
    want = ["ms_ELAPSED"] + [f"{c}_RAW" for c in CH]
    hsi_cols = [f"{c}_CONNECTION_STRENGTH(HSI)" for c in CH]
    gyro_cols = ["GYRO_X", "GYRO_Y", "GYRO_Z"]
    have_hsi = all(c in cols for c in hsi_cols)
    have_gyro = all(c in cols for c in gyro_cols)
    use = want + (hsi_cols if have_hsi else []) + (gyro_cols if have_gyro else [])
    missing = [c for c in want if c not in cols]
    if missing:
        raise ValueError(f"{os.path.basename(path)} lacks {missing}")
    if "PACKET_TYPE" in cols:
        use = ["PACKET_TYPE"] + use
    df = pd.read_csv(path, usecols=use, low_memory=False)
    if "PACKET_TYPE" in df.columns:
        df = df[df["PACKET_TYPE"].astype(str) == "EEG"].drop(columns=["PACKET_TYPE"])
    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["ms_ELAPSED"]).reset_index(drop=True)
    info = {"have_hsi": have_hsi, "have_gyro": have_gyro, "rows": int(len(df))}
    return df, info


def bandpower_log10(x: np.ndarray) -> np.ndarray:
    """log10 power in the four bands of one detrended epoch (uV^2)."""
    f, p = welch(x, fs=FS, nperseg=256, noverlap=128)
    out = np.empty(len(BANDS))
    for i, (lo, hi) in enumerate(BANDS.values()):
        m = (f >= lo) & (f < hi)
        out[i] = np.log10(max(np.trapezoid(p[m], f[m]), 1e-12))
    return out


def extract(path: str, stamp: str = "", device: str = "", meta: dict | None = None) -> Session:
    df, info = load_raw(path)
    t_s = df["ms_ELAPSED"].to_numpy(dtype=float) / 1000.0
    if len(t_s) == 0:
        raise ValueError(f"{os.path.basename(path)}: no EEG rows")
    t_s = t_s - t_s[0]
    # the last sample sits one sample period before the end of its epoch, and the clock is in whole milliseconds;
    # count that epoch as whole (the gap gate below still demands 90 % of its samples)
    n_ep = int(np.floor((t_s[-1] + 1.0 / FS) / EPOCH_S + 1e-3))
    idx = np.floor(t_s / EPOCH_S).astype(int)
    raw = np.stack([df[f"{c}_RAW"].to_numpy(dtype=float) for c in CH], axis=1)
    hsi_all = (np.stack([df[f"{c}_CONNECTION_STRENGTH(HSI)"].to_numpy(dtype=float) for c in CH], axis=1)
               if info["have_hsi"] else np.zeros_like(raw))
    gyro_norm = (np.sqrt(np.nansum(np.stack([df[c].to_numpy(dtype=float) for c in ("GYRO_X", "GYRO_Y", "GYRO_Z")],
                                             axis=1) ** 2, axis=1)) if info["have_gyro"] else None)
    if gyro_norm is not None:
        gyro_norm[~np.isfinite(df["GYRO_X"].to_numpy(dtype=float))] = np.nan
    # epoch boundaries from the sorted epoch index
    order = np.argsort(idx, kind="stable")
    idx_s, raw_s, hsi_s = idx[order], raw[order], hsi_all[order]
    gyro_s = gyro_norm[order] if gyro_norm is not None else None
    bounds = np.searchsorted(idx_s, np.arange(n_ep + 1))
    accepted = np.zeros((n_ep, 4), bool)
    logband = np.full((n_ep, 4, 4), np.nan)
    pp_uv = np.full((n_ep, 4), np.nan)
    hsi_med = np.zeros((n_ep, 4))
    n_samples = np.zeros(n_ep, int)
    gyro_rms = np.full(n_ep, np.nan)
    hsi_known = bool(info["have_hsi"]) and bool(np.nanmax(hsi_all) > 0)
    for e in range(n_ep):
        a, b = bounds[e], bounds[e + 1]
        n_samples[e] = b - a
        if gyro_s is not None and b > a:
            g = gyro_s[a:b]
            g = g[np.isfinite(g)]
            if len(g):
                gyro_rms[e] = float(np.sqrt(np.mean(g ** 2)))
        if b - a < MIN_SAMPLES:
            continue
        for c in range(4):
            x = raw_s[a:b, c]
            x = x[np.isfinite(x)]
            if len(x) < MIN_SAMPLES:
                continue
            pp = float(np.max(x) - np.min(x))
            pp_uv[e, c] = pp
            h = hsi_s[a:b, c]
            h = h[np.isfinite(h) & (h > 0)]
            hm = float(np.median(h)) if len(h) else 0.0
            hsi_med[e, c] = hm
            contact_ok = (hm <= HSI_OK and hm > 0) if hsi_known else True
            if pp < PP_MAX_UV and contact_ok:
                accepted[e, c] = True
                logband[e, c] = bandpower_log10(detrend(x))
    usable = accepted.sum(axis=1) >= 2
    with np.errstate(invalid="ignore"):
        lb = logband                                                   # (n, ch, band)
        lin = 10.0 ** lb
        idx_ch = np.log10((lin[:, :, 2] + lin[:, :, 3]) / (lin[:, :, 0] + lin[:, :, 1]))
        index = np.where(usable, np.nanmean(np.where(accepted, idx_ch, np.nan), axis=1), np.nan)
        logalpha = np.where(usable, np.nanmean(np.where(accepted, lb[:, :, 1], np.nan), axis=1), np.nan)
    t = np.arange(n_ep) * EPOCH_S
    m = dict(meta or {})
    m.update(info)
    m["hsi_known"] = hsi_known
    return Session(path=path, stamp=stamp, device=device, t=t, accepted=accepted, usable=usable, logband=logband,
                   index=index, logalpha=logalpha, gyro_rms=gyro_rms, pp_uv=pp_uv, hsi=hsi_med,
                   n_samples=n_samples, meta=m)
