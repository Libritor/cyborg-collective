"""Sequences, models, splits, skill, bootstrap and the null, exactly as pre-registered in PREDICTIONS.md.

Every sequence is k = 8 usable, contiguous epochs followed by h usable epochs; the target is the index at the
last of them. Skill is 1 - MSE(model) / MSE(persistence) on held-out time (protocol A) or held-out sessions
(protocol B). Models predict the CHANGE from the last value, so every model contains persistence.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

K = 8
HORIZONS = (1, 2, 4, 8)
MIN_SEQUENCES = 60          # a session must yield at least this many valid sequences at h = 1 to enter a pool
RIDGE_ALPHA = 1.0
N_BOOT = 2000
N_NULL = 200
NULL_MIN_SHIFT = 15


@dataclass
class Seqs:
    """Sequences of one session for one horizon."""
    stamp: str
    X_last: np.ndarray      # (n, 13): 8 lags of the target, 4 mean log band powers, gyro RMS at the last epoch
    X_seq: np.ndarray       # (n, k, 6): per step [target, theta, alpha, beta, gamma, gyro]
    y: np.ndarray           # (n,) target at t + h
    y_last: np.ndarray      # (n,) target at t (persistence)
    y_mean: np.ndarray      # (n,) expanding mean of the usable target up to t (the session-mean baseline)
    t: np.ndarray           # (n,) epoch start of the last history epoch

    @property
    def n(self) -> int:
        return int(len(self.y))


def _bands_mean(session) -> np.ndarray:
    with np.errstate(invalid="ignore"):
        lb = np.where(session.accepted[:, :, None], session.logband, np.nan)
        return np.nanmean(lb, axis=1)                                    # (n_ep, 4)


def build_sequences(session, h: int, k: int = K, target: str = "index") -> Seqs:
    y_all = session.index if target == "index" else session.logalpha
    usable = session.usable & np.isfinite(y_all)
    n = len(y_all)
    if n < k + h:
        return Seqs(session.stamp, np.zeros((0, k + 5)), np.zeros((0, k, 6)), np.zeros(0), np.zeros(0), np.zeros(0),
                    np.zeros(0))
    bands = _bands_mean(session)
    gyro = np.where(np.isfinite(session.gyro_rms), session.gyro_rms, 0.0)
    # valid[i]: epochs i-k+1 .. i+h all usable (a window of k+h ones in the usable run)
    cs = np.concatenate([[0], np.cumsum(usable.astype(int))])
    i = np.arange(k - 1, n - h)
    full = cs[i + h + 1] - cs[i - k + 1] == k + h
    i = i[full]
    if len(i) == 0:
        return Seqs(session.stamp, np.zeros((0, k + 5)), np.zeros((0, k, 6)), np.zeros(0), np.zeros(0), np.zeros(0),
                    np.zeros(0))
    lag_idx = i[:, None] - np.arange(k - 1, -1, -1)[None, :]          # (n, k) oldest .. newest
    lags = y_all[lag_idx]
    X_last = np.concatenate([lags, bands[i], gyro[i][:, None]], axis=1)
    X_seq = np.concatenate([lags[:, :, None], bands[lag_idx], gyro[lag_idx][:, :, None]], axis=2)
    # expanding mean of the usable target up to and including epoch i
    ys = np.where(usable, y_all, 0.0)
    csum = np.cumsum(ys)
    cnt = np.cumsum(usable.astype(int))
    y_mean = csum[i] / np.maximum(cnt[i], 1)
    return Seqs(session.stamp, X_last, X_seq, y_all[i + h], y_all[i], y_mean, session.t[i])


def concat(seqs: list[Seqs]) -> Seqs:
    if not seqs:
        return Seqs("", np.zeros((0, K + 5)), np.zeros((0, K, 6)), np.zeros(0), np.zeros(0), np.zeros(0), np.zeros(0))
    return Seqs("+".join(s.stamp for s in seqs), np.concatenate([s.X_last for s in seqs]),
                np.concatenate([s.X_seq for s in seqs]), np.concatenate([s.y for s in seqs]),
                np.concatenate([s.y_last for s in seqs]), np.concatenate([s.y_mean for s in seqs]),
                np.concatenate([s.t for s in seqs]))


# ---------------------------------------------------------------- models (each predicts the change from the last value)

class Ridge:
    def __init__(self, columns=None, alpha: float = RIDGE_ALPHA):
        self.columns = columns          # None = all features; slice(0, K) = lags only
        self.alpha = alpha

    def _cols(self, X):
        return X if self.columns is None else X[:, self.columns]

    def fit(self, s: Seqs):
        X = self._cols(s.X_last)
        self.mu = X.mean(axis=0)
        self.sd = X.std(axis=0) + 1e-9
        Z = (X - self.mu) / self.sd
        d = s.y - s.y_last
        A = Z.T @ Z + self.alpha * np.eye(Z.shape[1])
        self.w = np.linalg.solve(A, Z.T @ (d - d.mean()))
        self.b = float(d.mean())
        return self

    def predict(self, s: Seqs) -> np.ndarray:
        Z = (self._cols(s.X_last) - self.mu) / self.sd
        return s.y_last + Z @ self.w + self.b


class GRU:
    """A small GRU on the per-step features, predicting the change. Needs torch; CPU is fine, CUDA is used if there."""

    def __init__(self, hidden: int = 32, epochs: int = 30, lr: float = 1e-3, batch: int = 256, patience: int = 5,
                 seed: int = 0):
        self.hidden, self.epochs, self.lr, self.batch, self.patience, self.seed = hidden, epochs, lr, batch, patience, seed

    def fit(self, s: Seqs, val: Seqs | None = None):
        import torch
        import torch.nn as nn
        torch.manual_seed(self.seed)
        dev = "cuda" if torch.cuda.is_available() else "cpu"
        X = s.X_seq
        self.mu = X.reshape(-1, X.shape[-1]).mean(axis=0)
        self.sd = X.reshape(-1, X.shape[-1]).std(axis=0) + 1e-9
        d = s.y - s.y_last
        self.d_sd = float(d.std() + 1e-9)

        class Net(nn.Module):
            def __init__(self, nin, hidden):
                super().__init__()
                self.gru = nn.GRU(nin, hidden, batch_first=True)
                self.out = nn.Linear(hidden, 1)

            def forward(self, x):
                _, hN = self.gru(x)
                return self.out(hN[-1]).squeeze(-1)

        net = Net(X.shape[-1], self.hidden).to(dev)
        opt = torch.optim.Adam(net.parameters(), lr=self.lr)
        Xt = torch.tensor((X - self.mu) / self.sd, dtype=torch.float32, device=dev)
        dt = torch.tensor(d / self.d_sd, dtype=torch.float32, device=dev)
        if val is not None and val.n > 0:
            Xv = torch.tensor((val.X_seq - self.mu) / self.sd, dtype=torch.float32, device=dev)
            dv = torch.tensor((val.y - val.y_last) / self.d_sd, dtype=torch.float32, device=dev)
        else:
            Xv = dv = None
        best, best_state, bad = np.inf, None, 0
        n = len(dt)
        g = torch.Generator(device="cpu").manual_seed(self.seed)
        for _ in range(self.epochs):
            net.train()
            perm = torch.randperm(n, generator=g)
            for j in range(0, n, self.batch):
                idx = perm[j:j + self.batch].to(dev)
                opt.zero_grad()
                loss = torch.mean((net(Xt[idx]) - dt[idx]) ** 2)
                loss.backward()
                opt.step()
            if Xv is None:
                continue
            net.eval()
            with torch.no_grad():
                v = float(torch.mean((net(Xv) - dv) ** 2))
            if v < best - 1e-5:
                best, bad = v, 0
                best_state = {k_: v_.detach().clone() for k_, v_ in net.state_dict().items()}
            else:
                bad += 1
                if bad >= self.patience:
                    break
        if best_state is not None:
            net.load_state_dict(best_state)
        net.eval()
        self.net, self.dev = net, dev
        return self

    def predict(self, s: Seqs) -> np.ndarray:
        import torch
        with torch.no_grad():
            Xt = torch.tensor((s.X_seq - self.mu) / self.sd, dtype=torch.float32, device=self.dev)
            out = []
            for j in range(0, len(Xt), 4096):
                out.append(self.net(Xt[j:j + 4096]).cpu().numpy())
        return s.y_last + (np.concatenate(out) if out else np.zeros(0)) * self.d_sd


# ---------------------------------------------------------------- scoring

def sse(a, b) -> float:
    return float(np.sum((np.asarray(a) - np.asarray(b)) ** 2))


def score(s: Seqs, pred: np.ndarray) -> dict:
    return {"n": s.n, "sse_model": sse(pred, s.y), "sse_persist": sse(s.y_last, s.y), "sse_mean": sse(s.y_mean, s.y)}


def skill(rows: list[dict], against: str = "sse_persist") -> float:
    num = sum(r["sse_model"] for r in rows)
    den = sum(r[against] for r in rows)
    return float(1.0 - num / den) if den > 0 else float("nan")


def per_session_skills(rows, against="sse_persist") -> np.ndarray:
    return np.array([1.0 - r["sse_model"] / r[against] if r[against] > 0 else np.nan for r in rows])


def bootstrap(rows: list[dict], n_boot: int = N_BOOT, seed: int = 0, against="sse_persist") -> dict:
    """Resample sessions: intervals for the pooled skill and the median per-session skill."""
    rng = np.random.default_rng(seed)
    rows = [r for r in rows if r["n"] > 0]
    if not rows:
        return {"pooled": np.nan, "pooled_ci": [np.nan, np.nan], "median": np.nan, "median_ci": [np.nan, np.nan],
                "share_positive": np.nan, "sessions": 0}
    sm = np.array([r["sse_model"] for r in rows])
    sp = np.array([r[against] for r in rows])
    ps = per_session_skills(rows, against)
    pooled, med = [], []
    for _ in range(n_boot):
        ix = rng.integers(0, len(rows), len(rows))
        pooled.append(1.0 - sm[ix].sum() / max(sp[ix].sum(), 1e-12))
        med.append(np.nanmedian(ps[ix]))
    return {"pooled": float(1.0 - sm.sum() / sp.sum()), "pooled_ci": [float(np.percentile(pooled, 2.5)), float(np.percentile(pooled, 97.5))],
            "median": float(np.nanmedian(ps)), "median_ci": [float(np.percentile(med, 2.5)), float(np.percentile(med, 97.5))],
            "share_positive": float(np.nanmean(ps > 0)), "sessions": int(len(rows)), "sequences": int(sum(r["n"] for r in rows))}


def permuted(s: Seqs, rng) -> Seqs:
    """Each sequence keeps its target and its current value (the newest lag, which is also the persistence value);
    everything older or beside it (the 7 earlier lags, the band powers, the motion) comes from another sequence of
    the same session."""
    perm = rng.permutation(s.n)
    X_last = s.X_last[perm].copy()
    X_last[:, K - 1] = s.X_last[:, K - 1]
    X_seq = s.X_seq[perm].copy()
    X_seq[:, -1, 0] = s.X_seq[:, -1, 0]
    return Seqs(s.stamp, X_last, X_seq, s.y, s.y_last, s.y_mean, s.t)


def null_pvalue(tests: list[tuple[Seqs, object]], observed: float, n_null: int = N_NULL, seed: int = 0) -> float:
    """Does the older history add anything beyond the current value? Within each test session the older history is
    permuted among the sequences (see ``permuted``); the fitted model predicts from it and its skill over persistence
    is recomputed. p = share of permutations at or above the observed pooled skill (+1 smoothing). A model that only
    regresses the current value toward the mean keeps its skill under this null, so p is large for it.

    (A circular shift of the targets was pre-registered first; on synthetic data it credits any model that shrinks
    toward the mean, because persistence is a poor predictor of an unrelated series. Amended before the first run.)
    """
    rng = np.random.default_rng(seed)
    usable = [(s, m) for s, m in tests if s.n > NULL_MIN_SHIFT]
    if not usable:
        return float("nan")
    hits = 0
    for _ in range(n_null):
        num = den = 0.0
        for s, m in usable:
            p = m.predict(permuted(s, rng))
            num += sse(p, s.y)
            den += sse(s.y_last, s.y)
        if 1.0 - num / den >= observed:
            hits += 1
    return float((hits + 1) / (n_null + 1))


def holm(pvals: dict) -> dict:
    """Holm step-down over a dict name -> p; returns name -> adjusted p."""
    items = sorted(((p, k) for k, p in pvals.items() if np.isfinite(p)))
    m = len(items)
    out, running = {}, 0.0
    for rank, (p, k) in enumerate(items):
        adj = min(1.0, (m - rank) * p)
        running = max(running, adj)
        out[k] = running
    for k in pvals:
        out.setdefault(k, float("nan"))
    return out
