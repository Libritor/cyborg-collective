"""The claim gates on synthetic tables: a real difference is supported, a tiny group abstains, an opposite effect is
refuted, a forecast claim reads the held-out cell, and malformed claims are named as such."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from anticipate import claims  # noqa: E402


def _table(n_post=8, n_pre=8, shift=1.0, seed=0):
    rng = np.random.default_rng(seed)
    rows = []
    for i in range(n_post):
        rows.append({"key": f"post{i}", "pools": ["cold", "all"], "condition": "post", "mean_index": rng.normal(shift, 0.3),
                     "usable_fraction": rng.uniform(0.2, 0.6), "minutes": 10.0})
    for i in range(n_pre):
        rows.append({"key": f"pre{i}", "pools": ["cold", "all"], "condition": "pre", "mean_index": rng.normal(0.0, 0.3),
                     "usable_fraction": rng.uniform(0.6, 1.0), "minutes": 10.0})
    for i in range(12):
        rows.append({"key": f"m{i}", "pools": ["mine", "all"], "condition": "", "mean_index": rng.normal(0.2, 0.3),
                     "usable_fraction": 0.9 - 0.05 * i, "skill_A_h1": 0.02 + 0.02 * i, "minutes": 10.0})
    return rows


def test_compare_supported_refuted_and_underpowered():
    table = _table()
    post, pre = {"pool": "cold", "condition": "post"}, {"pool": "cold", "condition": "pre"}
    c_up = {"type": "compare_groups", "stat": "mean_index", "group_a": post, "group_b": pre, "direction": ">"}
    c_down = dict(c_up, direction="<")
    c_small = {"type": "compare_groups", "stat": "mean_index", "group_a": {"pool": "mine_sleep"}, "group_b": pre, "direction": ">"}
    res = claims.decide([claims.test_claim(c, table, None) for c in (c_up, c_down, c_small)])
    assert res[0]["outcome"] == "supported" and res[0]["p_stated_holm"] < 0.05
    assert res[1]["outcome"] == "refuted"
    assert res[2]["outcome"] == "abstain" and "underpowered" in res[2]["reason"]


def test_correlation_and_forecast_and_malformed():
    table = _table()
    corr = {"type": "correlation", "x": "usable_fraction", "y": "skill_A_h1", "pool": "mine", "sign": "-"}
    summary = {"cells": {"mine/A": {"ridge_all@1": {"persist": {"pooled": 0.12, "pooled_ci": [0.05, 0.19], "sessions": 12}}}}}
    f_ok = {"type": "forecast", "pool": "mine", "protocol": "A", "model": "ridge_all", "horizon": 1, "min_skill": 0.1}
    f_too_much = dict(f_ok, min_skill=0.3)
    f_missing = dict(f_ok, horizon=8)
    bad = [{"type": "compare_groups", "stat": "mean_index", "group_a": {"pool": "cold"}, "group_b": {"pool": "cold"}, "direction": ">"},
           {"type": "correlation", "x": "mean_index", "y": "mean_index", "pool": "all", "sign": "+"},
           {"type": "forecast", "pool": "mine", "model": "ridge_all", "horizon": 3, "min_skill": 0.1},
           {"type": "prophecy"}]
    res = claims.decide([claims.test_claim(c, table, summary) for c in [corr, f_ok, f_too_much, f_missing] + bad])
    assert res[0]["outcome"] == "supported" and res[0]["rho"] < -0.9
    assert res[1]["outcome"] == "supported"
    assert res[2]["outcome"] == "refuted"
    assert res[3]["outcome"] == "abstain"
    assert all(r["outcome"] == "malformed" for r in res[4:])


def test_overlapping_groups_are_malformed():
    table = _table()
    c = {"type": "compare_groups", "stat": "mean_index", "group_a": {"pool": "cold", "condition": "any"},
         "group_b": {"pool": "all", "condition": "pre"}, "direction": ">"}
    assert claims.test_claim(c, table, None)["outcome"] == "malformed"
