"""The forecasting machinery on synthetic series: no future leaks into a sequence, an AR(1) series is predictable
at h = 1 and less so at h = 8, white noise earns no skill, and Holm behaves."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from anticipate import epochs, forecast  # noqa: E402


def _session(y, usable=None, stamp="s"):
    n = len(y)
    usable = np.ones(n, bool) if usable is None else usable
    acc = np.repeat(usable[:, None], 4, axis=1)
    lb = np.full((n, 4, 4), np.nan)
    lb[usable] = np.random.default_rng(1).normal(0, 0.1, (int(usable.sum()), 4, 4))
    return epochs.Session(path="", stamp=stamp, device="Muse1", t=np.arange(n) * 2.0, accepted=acc, usable=usable,
                          logband=lb, index=np.where(usable, y, np.nan), logalpha=np.where(usable, y, np.nan),
                          gyro_rms=np.zeros(n), pp_uv=np.zeros((n, 4)), hsi=np.ones((n, 4)), n_samples=np.full(n, 512))


def _ar1(n, phi=0.9, seed=0):
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    for i in range(1, n):
        y[i] = phi * y[i - 1] + rng.normal(0, 1)
    return y


def test_sequences_use_only_the_past_and_skip_unusable_windows():
    y = np.arange(40, dtype=float)
    usable = np.ones(40, bool)
    usable[20] = False
    s = forecast.build_sequences(_session(y, usable), h=2)
    # every lag is older than the target, and the newest lag is exactly the persistence value
    assert (s.X_last[:, :forecast.K].max(axis=1) == s.y_last).all()
    assert (s.y == s.y_last + 2).all()
    # no window may contain epoch 20: windows ending at t+h in 20..., or starting before 20 and ending after it
    bad = [(a, b) for a, b in zip(s.y_last - forecast.K + 1, s.y) if a <= 20 <= b]
    assert not bad
    assert s.n == 40 - forecast.K - 2 + 1 - (forecast.K + 2)


def test_ar1_skill_matches_theory_and_fades_against_the_mean_with_horizon():
    # AR(1), phi = 0.5: var = 4/3; one step ahead persistence errs 2 var (1 - phi) = 4/3, the optimal predictor 1,
    # so skill over persistence ~ 0.25. Eight steps ahead the optimal predictor is nearly the mean, so skill over
    # the session mean falls toward 0 while skill over persistence does not (persistence is a poor long baseline).
    y = _ar1(6000, phi=0.5)
    sess = _session(y)
    out = {}
    for h in (1, 8):
        s = forecast.build_sequences(sess, h=h)
        cut = int(0.6 * s.n)
        tr = forecast.Seqs("tr", s.X_last[:cut], s.X_seq[:cut], s.y[:cut], s.y_last[:cut], s.y_mean[:cut], s.t[:cut])
        te = forecast.Seqs("te", s.X_last[cut:], s.X_seq[cut:], s.y[cut:], s.y_last[cut:], s.y_mean[cut:], s.t[cut:])
        pred = forecast.Ridge(columns=slice(0, forecast.K)).fit(tr).predict(te)
        row = forecast.score(te, pred)
        out[h] = (forecast.skill([row]), forecast.skill([row], against="sse_mean"))
    assert 0.15 < out[1][0] < 0.35
    assert out[8][1] < out[1][1] and out[8][1] < 0.05
    # a strongly persistent series: persistence is already near-optimal one step ahead (theory: 0.05)
    s = forecast.build_sequences(_session(_ar1(6000, phi=0.9)), h=1)
    cut = int(0.6 * s.n)
    tr = forecast.Seqs("tr", s.X_last[:cut], s.X_seq[:cut], s.y[:cut], s.y_last[:cut], s.y_mean[:cut], s.t[:cut])
    te = forecast.Seqs("te", s.X_last[cut:], s.X_seq[cut:], s.y[cut:], s.y_last[cut:], s.y_mean[cut:], s.t[cut:])
    pred = forecast.Ridge(columns=slice(0, forecast.K)).fit(tr).predict(te)
    assert 0.0 < forecast.skill([forecast.score(te, pred)]) < 0.12


def test_white_noise_earns_no_skill_over_the_session_mean_but_beats_persistence():
    y = np.random.default_rng(3).normal(0, 1, 3000)
    s = forecast.build_sequences(_session(y), h=1)
    cut = int(0.6 * s.n)
    tr = forecast.Seqs("tr", s.X_last[:cut], s.X_seq[:cut], s.y[:cut], s.y_last[:cut], s.y_mean[:cut], s.t[:cut])
    te = forecast.Seqs("te", s.X_last[cut:], s.X_seq[cut:], s.y[cut:], s.y_last[cut:], s.y_mean[cut:], s.t[cut:])
    pred = forecast.Ridge().fit(tr).predict(te)
    row = forecast.score(te, pred)
    assert forecast.skill([row], against="sse_mean") < 0.05          # cannot beat the mean on noise
    assert forecast.skill([row]) > 0.3                               # persistence is a bad baseline on noise


def test_bootstrap_and_null_and_holm_shapes():
    def fit_and_p(y, seed=0):
        s = forecast.build_sequences(_session(y), h=1)
        cut = s.n // 2
        tr = forecast.Seqs("tr", s.X_last[:cut], s.X_seq[:cut], s.y[:cut], s.y_last[:cut], s.y_mean[:cut], s.t[:cut])
        te = forecast.Seqs("te", s.X_last[cut:], s.X_seq[cut:], s.y[cut:], s.y_last[cut:], s.y_mean[cut:], s.t[cut:])
        model = forecast.Ridge(columns=slice(0, forecast.K)).fit(tr)
        rows = [forecast.score(te, model.predict(te))]
        return rows, forecast.null_pvalue([(te, model)], observed=forecast.skill(rows), n_null=60, seed=seed), te, model

    # AR(2): the value two steps back carries information the current value does not -> the older history matters
    rng = np.random.default_rng(7)
    y2 = np.zeros(4000)
    for i in range(2, 4000):
        y2[i] = 0.3 * y2[i - 1] + 0.55 * y2[i - 2] + rng.normal(0, 1)
    rows, p, te, model = fit_and_p(y2)
    b = forecast.bootstrap(rows, n_boot=50)
    assert b["sessions"] == 1 and np.isfinite(b["pooled"])
    assert 0 < p < 0.1
    # AR(1) and white noise: everything is in the current value; permuting the older history changes nothing
    assert fit_and_p(_ar1(4000, phi=0.5))[1] > 0.1
    assert fit_and_p(np.random.default_rng(5).normal(0, 1, 4000))[1] > 0.1
    # the permutation keeps the current value and the target with each sequence
    pm = forecast.permuted(te, np.random.default_rng(1))
    assert (pm.X_last[:, forecast.K - 1] == te.X_last[:, forecast.K - 1]).all() and (pm.y == te.y).all()
    assert not (pm.X_last[:, 0] == te.X_last[:, 0]).all()
    adj = forecast.holm({"a": 0.01, "b": 0.04, "c": 0.5})
    assert adj["a"] == 0.03 and adj["b"] == 0.08 and adj["c"] == 0.5


def test_gru_runs_small():
    y = _ar1(600)
    s = forecast.build_sequences(_session(y), h=1)
    cut = s.n // 2
    tr = forecast.Seqs("tr", s.X_last[:cut], s.X_seq[:cut], s.y[:cut], s.y_last[:cut], s.y_mean[:cut], s.t[:cut])
    te = forecast.Seqs("te", s.X_last[cut:], s.X_seq[cut:], s.y[cut:], s.y_last[cut:], s.y_mean[cut:], s.t[cut:])
    pred = forecast.GRU(epochs=3).fit(tr, val=te).predict(te)
    assert pred.shape == te.y.shape and np.isfinite(pred).all()
