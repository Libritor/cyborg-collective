"""The gate and the pools on synthetic data: the 200 uV rule, the contact rule, the gap rule, the pools' rules."""
import os
import sys
import tempfile

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from anticipate import epochs, pools  # noqa: E402


def _csv(path, seconds=10, pp=50.0, hsi=1, gap_epoch=None, alpha_hz=10.0):
    n = int(epochs.FS * seconds)
    t = np.arange(n) / epochs.FS
    rng = np.random.default_rng(0)
    rows = {"PACKET_TYPE": ["EEG"] * n, "ms_ELAPSED": (t * 1000).astype(int)}
    for c in epochs.CH:
        x = 800 + (pp / 2) * np.sin(2 * np.pi * alpha_hz * t) + rng.normal(0, 2, n)
        rows[f"{c}_RAW"] = x
        rows[f"{c}_CONNECTION_STRENGTH(HSI)"] = hsi
    for g in ("GYRO_X", "GYRO_Y", "GYRO_Z"):
        rows[g] = rng.normal(0, 1, n)
    df = pd.DataFrame(rows)
    if gap_epoch is not None:                      # drop most samples of one epoch
        lo, hi = gap_epoch * epochs.N_EPOCH, gap_epoch * epochs.N_EPOCH + 100
        df = df.drop(df.index[lo:hi])
    df.to_csv(path, index=False)
    return path


def test_clean_signal_is_accepted_and_alpha_dominates():
    with tempfile.TemporaryDirectory() as d:
        s = epochs.extract(_csv(os.path.join(d, "muse_session_20260101_120000_Muse1.csv")))
        assert s.n_epochs == 5 and s.usable.all()
        assert s.accepted.all()
        # a 10 Hz sine: alpha power above every other band on every channel
        assert (np.argmax(np.nanmean(s.logband, axis=0), axis=1) == 1).all()
        assert np.isfinite(s.index).all() and np.isfinite(s.gyro_rms).all()


def test_200_uv_swing_is_rejected():
    with tempfile.TemporaryDirectory() as d:
        s = epochs.extract(_csv(os.path.join(d, "muse_session_20260101_120000_Muse1.csv"), pp=260.0))
        assert not s.accepted.any() and not s.usable.any()
        assert np.isnan(s.index).all()


def test_poor_contact_is_rejected_when_hsi_is_known():
    with tempfile.TemporaryDirectory() as d:
        s = epochs.extract(_csv(os.path.join(d, "muse_session_20260101_120000_Muse1.csv"), hsi=4))
        assert not s.accepted.any()


def test_gap_epoch_is_rejected_and_neighbours_stand():
    with tempfile.TemporaryDirectory() as d:
        s = epochs.extract(_csv(os.path.join(d, "muse_session_20260101_120000_Muse1.csv"), gap_epoch=2))
        assert not s.usable[2] and s.usable[[0, 1, 3, 4]].all()
        assert s.n_samples[2] < epochs.MIN_SAMPLES


def test_npz_round_trip():
    with tempfile.TemporaryDirectory() as d:
        s = epochs.extract(_csv(os.path.join(d, "muse_session_20260101_120000_Muse1.csv")), stamp="x", device="Muse1",
                           meta={"pools": ["all"]})
        p = os.path.join(d, "out", "x.npz")
        s.to_npz(p)
        s2 = epochs.Session.from_npz(p)
        assert s2.n_epochs == s.n_epochs and np.allclose(s2.index, s.index) and s2.meta["pools"] == ["all"]


def test_pool_rules():
    r = pools.classify(r"C:\x\muse_session_20251210_101010_Muse1.csv")
    assert "mine" in r.pools and "cold" not in r.pools
    r = pools.classify(r"C:\x\muse_session_20251210_101010_Muse2.csv")
    assert "mine" not in r.pools                                   # another headband in the recorder period
    r = pools.classify(r"C:\x\muse_session_20260225_135128_AlexBefore.csv")
    assert "mine" in r.pools and "cold" in r.pools and r.condition == "pre"
    r = pools.classify(r"C:\x\muse_session_20260225_140620_ChanBefore.csv")
    assert "mine" not in r.pools and "cold" in r.pools and r.condition == "pre"
    r = pools.classify(r"C:\x\muse_session_20261023_160759_Muse1.csv")
    assert "mine" not in r.pools and "cold" in r.pools and r.condition == "cold"
    r = pools.classify(r"C:\x\muse_session_20261027_012222_Muse1.csv")
    assert "mine_sleep" in r.pools and "mine" not in r.pools and r.condition == "sleep"
    assert pools.classify(r"C:\x\notes.csv") is None
