Rosbagged room, 6 November 2026 (Meta Quest 3S + Muse, ROS 2 bag -> COLMAP -> mesh)

room_100mm.stl   the room as one closed body, 91 x 98 x 106 mm, Z up. Print with supports (H2C: about 4 h 35 min, 85 g PLA).
room_relief.stl  floor-plan relief, 150 x 142 mm, 10 mm of relief. Print flat, no supports, no brim (H2C: about 57 min, 44 g).

Both are decimated to 240k triangles for download; the full-resolution STLs and the sliced H2C 3MFs are in Downloads/quest_room_20261106 on the capture laptop.
Live viewer of the same room: http://6ense.com/space/
